import sys
import os
import time
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from parser import ler_instancias
from problema import Problema
from greedy import greedy_cobertura_maxima, greedy_face_mais_restrita, greedy_grasp
from mac_ac3 import SolverMAC
from ilp_ortools import resolver_ilp, lower_bound_lp
from prog_dinamica import resolver_dp
from extensoes import construir_grafo_conflito, colorir_greedy, comparar_alcances


def demo(ficheiro='data/parts40.txt', idx=0):
    instancias = ler_instancias(ficheiro)
    prob = Problema(instancias[idx])

    print(f"\n{'='*55}")
    print(f"  Instância {idx} — '{ficheiro}'")
    print(f"  Faces: {prob.n_faces}   Vértices: {prob.n_vertices}")
    print(f"{'='*55}\n")

    lb = lower_bound_lp(prob)
    print(f"  Lower bound (LP): {lb:.2f}\n")

    for nome, fn in [
        ("G1 – Cobertura Máxima  ", greedy_cobertura_maxima),
        ("G2 – Face Mais Restrita", greedy_face_mais_restrita),
    ]:
        t0 = time.perf_counter()
        guardas, custo = fn(prob)
        ms = (time.perf_counter() - t0) * 1000
        print(f"  {nome}: {custo:>3} guardas  ({ms:.1f}ms)  válido={prob.e_valido(set(guardas))}")

    t0 = time.perf_counter()
    _, c3 = greedy_grasp(prob, n_tentativas=20, semente=42)
    ms = (time.perf_counter() - t0) * 1000
    print(f"  G3 – GRASP (20 tentativas): {c3:>3} guardas  ({ms:.1f}ms)")

    t0 = time.perf_counter()
    mac = SolverMAC(limite_nos=5000, achar_otimo=True)
    _, custo_mac = mac.resolver(prob)
    ms = (time.perf_counter() - t0) * 1000
    print(f"  MAC + AC-3              : {custo_mac:>3} guardas  ({ms:.0f}ms)  nós={mac.nos_explorados}")

    t0 = time.perf_counter()
    _, custo_ilp = resolver_ilp(prob, tempo_limite=30)
    ms = (time.perf_counter() - t0) * 1000
    print(f"  ILP (OR-Tools)          : {custo_ilp:>3} guardas  ({ms:.0f}ms)")

    t0 = time.perf_counter()
    _, custo_dp = resolver_dp(prob)
    ms = (time.perf_counter() - t0) * 1000
    print(f"  DP (column sweep)       : {custo_dp:>3} guardas  ({ms:.0f}ms)")

    print(f"\n  Extensão 4a – Guardas com Cores:")
    gs_g1, _ = greedy_cobertura_maxima(prob)
    conflito = construir_grafo_conflito(prob, gs_g1)
    coloracao = colorir_greedy(conflito, gs_g1)
    n_cores = max(coloracao.values()) if coloracao else 0
    print(f"    {len(gs_g1)} guardas → {n_cores} cores")

    print(f"\n  Extensão 4b – Alcance D:")
    for D, n_g in comparar_alcances(prob, [0, 1, 2, 3]).items():
        print(f"    D={D}: {n_g} guardas")

    print()


def correr_experiencias(ficheiro='data/parts40.txt', n=20):
    instancias = ler_instancias(ficheiro)[:n]

    print(f"\n{'='*65}")
    print(f"  Experiências: {ficheiro}  ({len(instancias)} instâncias)")
    print(f"{'='*65}")
    print(f"{'#':>3} {'|V|':>5} {'LB':>5} {'G1':>4} {'G2':>4} {'G3':>4} {'MAC':>5} {'ILP':>4} {'DP':>4}")
    print("-" * 65)

    totais = {k: 0 for k in ['g1','g2','g3','mac','ilp','dp']}
    n_val  = {k: 0 for k in totais}

    for i, inst in enumerate(instancias, 1):
        prob = Problema(inst)
        lb = lower_bound_lp(prob)

        _, c1 = greedy_cobertura_maxima(prob)
        _, c2 = greedy_face_mais_restrita(prob)
        _, c3 = greedy_grasp(prob, n_tentativas=20, semente=42)

        mac = SolverMAC(limite_nos=5000)
        _, cm = mac.resolver(prob)

        _, ci = resolver_ilp(prob, tempo_limite=30)
        _, cd = resolver_dp(prob)

        for k, v in [('g1',c1),('g2',c2),('g3',c3),('mac',cm),('ilp',ci),('dp',cd)]:
            if v > 0:
                totais[k] += v
                n_val[k]  += 1

        print(f"{i:>3} {prob.n_vertices:>5} {lb:>5.1f} {c1:>4} {c2:>4} {c3:>4} "
              f"{str(cm) if cm > 0 else ' — ':>5} {ci:>4} {cd:>4}")

    print("-" * 65)
    print("Médias:", end="  ")
    for k in ['g1','g2','g3','mac','ilp','dp']:
        if n_val[k] > 0:
            print(f"{k.upper()}={totais[k]/n_val[k]:.1f}", end="  ")
    print()


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description='Vigilância de Partições Retangulares')
    ap.add_argument('--ficheiro',     default='data/parts40.txt')
    ap.add_argument('--instancia',    type=int, default=0)
    ap.add_argument('--experiencias', action='store_true')
    ap.add_argument('--n',            type=int, default=20)
    args = ap.parse_args()

    if args.experiencias:
        correr_experiencias(args.ficheiro, args.n)
    else:
        demo(args.ficheiro, args.instancia)
