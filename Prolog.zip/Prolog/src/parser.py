def ler_instancias(caminho):
    # formato: nº instâncias, depois para cada uma: nº faces,
    # e para cada face: id, nº vértices, coordenadas x y
    with open(caminho) as f:
        tokens = f.read().split()

    pos = 0
    n_inst = int(tokens[pos]); pos += 1
    instancias = []

    for _ in range(n_inst):
        n_faces = int(tokens[pos]); pos += 1
        faces = {}

        for _ in range(n_faces):
            id_face = int(tokens[pos]); pos += 1
            n_verts = int(tokens[pos]); pos += 1
            verts = []
            for _ in range(n_verts):
                x = int(tokens[pos]); pos += 1
                y = int(tokens[pos]); pos += 1
                verts.append((x, y))
            faces[id_face] = verts

        instancias.append(faces)

    return instancias
