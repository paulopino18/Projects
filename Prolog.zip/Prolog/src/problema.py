from collections import defaultdict


class Problema:

    def __init__(self, instancia, faces_obrigatorias=None):
        self.faces = instancia

        if faces_obrigatorias is None:
            self.obrigatorias = set(instancia.keys())
        else:
            self.obrigatorias = set(faces_obrigatorias)

        # para cada vértice, quais faces ele cobre
        self.vertice_faces = defaultdict(set)
        for id_face, verts in instancia.items():
            for v in verts:
                self.vertice_faces[v].add(id_face)

        self.vertices  = sorted(self.vertice_faces.keys())
        self.ids_faces = sorted(instancia.keys())
        self.n_faces    = len(instancia)
        self.n_vertices = len(self.vertices)

        self.adjacentes = self._construir_adjacencia()

    def _construir_adjacencia(self):
        adj = defaultdict(set)
        for verts in self.faces.values():
            n = len(verts)
            for i in range(n):
                u = verts[i]
                w = verts[(i + 1) % n]
                adj[u].add(w)
                adj[w].add(u)
        return adj

    def vertices_da_face(self, id_face):
        return list(dict.fromkeys(self.faces[id_face]))

    def faces_cobertas(self, guardas):
        cobertas = set()
        for g in guardas:
            cobertas |= self.vertice_faces.get(g, set())
        return cobertas & self.obrigatorias

    def e_valido(self, guardas):
        return self.faces_cobertas(guardas) == self.obrigatorias

    def nao_cobertas(self, guardas):
        return self.obrigatorias - self.faces_cobertas(guardas)

    def vizinhos_ate_distancia(self, v, D):
        visitados = {v}
        fronteira = {v}
        for _ in range(D):
            proxima = set()
            for u in fronteira:
                for w in self.adjacentes.get(u, set()):
                    if w not in visitados:
                        visitados.add(w)
                        proxima.add(w)
            fronteira = proxima
        return visitados

    def __repr__(self):
        return f"Problema(faces={self.n_faces}, vertices={self.n_vertices})"
