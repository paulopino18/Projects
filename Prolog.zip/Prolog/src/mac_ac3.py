import sys


class Dominios:
    # guarda o domínio {0,1} de cada vértice durante a pesquisa

    def __init__(self, vertices):
        self._dom = {v: {0, 1} for v in vertices}

    def copiar(self):
        copia = Dominios([])
        copia._dom = {v: s.copy() for v, s in self._dom.items()}
        return copia

    def fixar(self, v, valor):
        self._dom[v] = {valor}

    def remover(self, v, valor):
        self._dom[v].discard(valor)

    def esta_fixo(self, v):
        return len(self._dom[v]) == 1

    def valor(self, v):
        if self.esta_fixo(v):
            return next(iter(self._dom[v]))
        return None

    def esta_vazio(self, v):
        return len(self._dom[v]) == 0

    def valores(self, v):
        return self._dom[v]


def ac3(prob, doms, faces_obrigatorias):
    # propaga restrições: se uma face só tem um vértice possível, força-o a 1
    # devolve False se encontrar inconsistência
    fila = set(faces_obrigatorias)

    houve_alteracao = True
    while houve_alteracao:
        houve_alteracao = False

        for f in list(fila):
            verts = prob.vertices_da_face(f)

            if any(doms.valor(v) == 1 for v in verts):
                fila.discard(f)
                continue

            podem_ser_1 = [v for v in verts if 1 in doms.valores(v)]

            if len(podem_ser_1) == 0:
                return False

            if len(podem_ser_1) == 1:
                v = podem_ser_1[0]
                if not doms.esta_fixo(v):
                    doms.fixar(v, 1)
                    houve_alteracao = True
                    for f2 in prob.vertice_faces.get(v, set()):
                        if f2 in faces_obrigatorias:
                            fila.add(f2)

    for v in prob.vertices:
        if doms.esta_vazio(v):
            return False

    return True


def escolher_variavel(prob, doms, faces_obrigatorias):
    # escolhe o vértice livre que aparece em mais faces ainda por cobrir
    nao_cobertas = {
        f for f in faces_obrigatorias
        if not any(doms.valor(v) == 1 for v in prob.vertices_da_face(f))
    }

    if not nao_cobertas:
        return None

    melhor_v = None
    melhor_grau = -1

    for v in prob.vertices:
        if not doms.esta_fixo(v):
            grau = len(prob.vertice_faces.get(v, set()) & nao_cobertas)
            if grau > melhor_grau:
                melhor_grau = grau
                melhor_v = v

    return melhor_v


class SolverMAC:

    def __init__(self, limite_nos=500_000, achar_otimo=True):
        self.limite_nos = limite_nos
        self.achar_otimo = achar_otimo
        self.nos_explorados = 0
        self._melhor_custo = sys.maxsize
        self._melhor_solucao = None

    def resolver(self, prob, faces=None):
        if faces is None:
            faces = prob.obrigatorias

        self.nos_explorados = 0
        self._melhor_custo = sys.maxsize
        self._melhor_solucao = None

        doms = Dominios(prob.vertices)

        if not ac3(prob, doms, faces):
            return None, -1

        self._backtrack(prob, doms, faces)

        if self._melhor_solucao is None:
            return None, -1

        return sorted(self._melhor_solucao), self._melhor_custo

    def _backtrack(self, prob, doms, faces):
        self.nos_explorados += 1

        if self.limite_nos and self.nos_explorados > self.limite_nos:
            return

        custo_parcial = sum(1 for v in prob.vertices if doms.valor(v) == 1)

        if custo_parcial >= self._melhor_custo:
            return

        nao_cobertas = {
            f for f in faces
            if not any(doms.valor(v) == 1 for v in prob.vertices_da_face(f))
        }

        if not nao_cobertas:
            guardas = {v for v in prob.vertices if doms.valor(v) == 1}
            custo = len(guardas)
            if custo < self._melhor_custo:
                self._melhor_custo = custo
                self._melhor_solucao = guardas
            return

        var = escolher_variavel(prob, doms, faces)
        if var is None:
            return

        # tentamos 0 primeiro para minimizar guardas
        for valor in [0, 1]:
            novos_doms = doms.copiar()
            novos_doms.fixar(var, valor)
            if ac3(prob, novos_doms, faces):
                self._backtrack(prob, novos_doms, faces)
