import random


def greedy_cobertura_maxima(prob, faces=None):
    # a cada passo escolhemos o vértice que cobre mais faces ainda por cobrir
    # é a abordagem clássica para Set Cover
    if faces is None:
        faces = prob.obrigatorias.copy()

    por_cobrir = set(faces)
    guardas = []

    while por_cobrir:
        melhor = max(
            prob.vertices,
            key=lambda v: len(prob.vertice_faces.get(v, set()) & por_cobrir)
        )
        guardas.append(melhor)
        por_cobrir -= prob.vertice_faces.get(melhor, set())

    return guardas, len(guardas)


def greedy_face_mais_restrita(prob, faces=None):
    # inspirado no fail-first dos CSPs: trata primeiro as faces mais difíceis
    # (as que têm menos vértices disponíveis)
    if faces is None:
        faces = prob.obrigatorias.copy()

    por_cobrir = set(faces)
    guardas = []
    usados = set()

    while por_cobrir:
        face_dificil = None
        menos_opcoes = float('inf')
        candidatos = []

        for f in por_cobrir:
            verts = prob.vertices_da_face(f)
            livres = [v for v in verts if v not in usados]
            if len(livres) < menos_opcoes:
                menos_opcoes = len(livres)
                face_dificil = f
                candidatos = livres

        if not candidatos:
            break

        melhor = max(
            candidatos,
            key=lambda v: len(prob.vertice_faces.get(v, set()) & por_cobrir)
        )
        guardas.append(melhor)
        usados.add(melhor)
        por_cobrir -= prob.vertice_faces.get(melhor, set())

    return guardas, len(guardas)


def greedy_grasp(prob, faces=None, n_tentativas=30, alpha=0.3, semente=None):
    # versão aleatorizada do greedy com múltiplos reinícios
    # em vez do melhor vértice, escolhemos aleatoriamente entre os "bons o suficiente"
    if faces is None:
        faces = prob.obrigatorias.copy()

    rng = random.Random(semente)
    melhor_guardas = None
    melhor_custo = float('inf')

    for _ in range(n_tentativas):
        por_cobrir = set(faces)
        guardas = []

        while por_cobrir:
            ganhos = {
                v: len(prob.vertice_faces.get(v, set()) & por_cobrir)
                for v in prob.vertices
                if prob.vertice_faces.get(v, set()) & por_cobrir
            }
            if not ganhos:
                break

            gmax = max(ganhos.values())
            gmin = min(ganhos.values())
            threshold = gmax - alpha * (gmax - gmin)
            candidatos = [v for v, g in ganhos.items() if g >= threshold]

            escolhido = rng.choice(candidatos)
            guardas.append(escolhido)
            por_cobrir -= prob.vertice_faces.get(escolhido, set())

        if len(guardas) < melhor_custo:
            melhor_custo = len(guardas)
            melhor_guardas = guardas[:]

    return melhor_guardas, melhor_custo


def comparar_greedy(prob, n_tentativas_grasp=30):
    g1, c1 = greedy_cobertura_maxima(prob)
    g2, c2 = greedy_face_mais_restrita(prob)
    g3, c3 = greedy_grasp(prob, n_tentativas=n_tentativas_grasp, semente=42)

    print("Resultados greedy:")
    print(f"  Cobertura Máxima   : {c1} guardas  (válido={prob.e_valido(set(g1))})")
    print(f"  Face Mais Restrita : {c2} guardas  (válido={prob.e_valido(set(g2))})")
    print(f"  GRASP ({n_tentativas_grasp} tentativas): {c3} guardas  (válido={prob.e_valido(set(g3))})")

    return (g1, c1), (g2, c2), (g3, c3)
