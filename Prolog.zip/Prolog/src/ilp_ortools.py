from ortools.sat.python import cp_model


def resolver_ilp(prob, faces=None, tempo_limite=30.0):
    if faces is None:
        faces = prob.obrigatorias

    model = cp_model.CpModel()

    # variável binária por vértice: 1 = colocar guarda
    x = {v: model.NewBoolVar(f"g_{v[0]}_{v[1]}") for v in prob.vertices}

    # cada face precisa de pelo menos um guarda
    for f in faces:
        verts = prob.vertices_da_face(f)
        model.AddBoolOr([x[v] for v in verts])

    model.Minimize(sum(x[v] for v in prob.vertices))

    # hint inicial com solução greedy para acelerar a pesquisa
    try:
        from greedy import greedy_cobertura_maxima
        gs_greedy, _ = greedy_cobertura_maxima(prob, faces)
        conj = set(gs_greedy)
        for v in prob.vertices:
            model.AddHint(x[v], 1 if v in conj else 0)
    except Exception:
        pass

    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = tempo_limite
    solver.parameters.num_workers = 4

    status = solver.Solve(model)

    if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        guardas = [v for v in prob.vertices if solver.Value(x[v]) == 1]
        return guardas, len(guardas)

    return None, -1


def lower_bound_lp(prob, faces=None):
    # relaxação LP: x_v em [0,1] em vez de {0,1}
    # o ótimo da LP é um limite inferior do ótimo inteiro
    try:
        from scipy.optimize import linprog
        import numpy as np
    except ImportError:
        return 0.0

    if faces is None:
        faces = prob.obrigatorias

    n = len(prob.vertices)
    indice_v = {v: i for i, v in enumerate(prob.vertices)}
    lista_faces = list(faces)
    m = len(lista_faces)

    if m == 0:
        return 0.0

    c = [1.0] * n
    linhas, colunas, dados = [], [], []

    for i, f in enumerate(lista_faces):
        for v in prob.vertices_da_face(f):
            linhas.append(i)
            colunas.append(indice_v[v])
            dados.append(-1.0)

    from scipy.sparse import csr_matrix
    A = csr_matrix((dados, (linhas, colunas)), shape=(m, n))
    b = [-1.0] * m
    limites = [(0.0, 1.0)] * n

    res = linprog(c, A_ub=A, b_ub=b, bounds=limites, method='highs')
    return float(res.fun) if res.success else 0.0


def resolver_ilp_mip(prob, faces=None, tempo_limite=30.0):
    from ortools.linear_solver import pywraplp

    if faces is None:
        faces = prob.obrigatorias

    solver = pywraplp.Solver.CreateSolver('SCIP')
    solver.set_time_limit(int(tempo_limite * 1000))

    x = {v: solver.IntVar(0, 1, f'x_{v[0]}_{v[1]}') for v in prob.vertices}

    for f in faces:
        verts = prob.vertices_da_face(f)
        solver.Add(sum(x[v] for v in verts) >= 1)

    obj = solver.Objective()
    for v in prob.vertices:
        obj.SetCoefficient(x[v], 1)
    obj.SetMinimization()

    status = solver.Solve()
    if status == pywraplp.Solver.OPTIMAL:
        guardas = [v for v in prob.vertices if x[v].solution_value() > 0.5]
        return guardas, len(guardas)

    return None, -1
