from collections import defaultdict

# limite de vértices por coluna para o DP exacto
# acima disto usamos a versão heurística
MAX_VERTS_COLUNA = 12


def _preparar_estruturas(prob, faces):
    # coordenadas X distintas definem as colunas
    coords_x = sorted({v[0] for v in prob.vertices})
    idx_x = {x: i for i, x in enumerate(coords_x)}

    verts_coluna = defaultdict(list)
    for v in prob.vertices:
        verts_coluna[v[0]].append(v)
    for x in coords_x:
        verts_coluna[x].sort(key=lambda v: v[1])

    lista_faces = sorted(faces)
    face_bit = {f: i for i, f in enumerate(lista_faces)}

    intervalos = {}
    for f in faces:
        xs = [v[0] for v in prob.vertices_da_face(f)]
        intervalos[f] = (idx_x[min(xs)], idx_x[max(xs)])

    cob_vertice = {}
    for v in prob.vertices:
        mask = 0
        for f in prob.vertice_faces.get(v, set()):
            if f in face_bit:
                mask |= (1 << face_bit[f])
        cob_vertice[v] = mask

    K = len(coords_x)
    mask_ativa    = [0] * K
    mask_entrada  = [0] * K
    mask_deadline = [0] * K

    for f, (li, ri) in intervalos.items():
        bit = 1 << face_bit[f]
        for ci in range(li, ri + 1):
            mask_ativa[ci] |= bit
        mask_entrada[li]  |= bit
        mask_deadline[ri] |= bit

    return (coords_x, verts_coluna, cob_vertice,
            mask_ativa, mask_entrada, mask_deadline)


def resolver_dp(prob, faces=None):
    # DP exacto por column sweep: processa a partição coluna a coluna
    if faces is None:
        faces = prob.obrigatorias

    (coords_x, verts_coluna, cob_vertice,
     mask_ativa, mask_entrada, mask_deadline) = _preparar_estruturas(prob, faces)

    K = len(coords_x)
    estado_inicial = mask_entrada[0]
    dp = {estado_inicial: (0, [])}

    for ci in range(K):
        x = coords_x[ci]
        verts = verts_coluna[x]
        n = len(verts)

        if n > MAX_VERTS_COLUNA:
            return resolver_dp_heuristico(prob, faces)

        coberturas = [cob_vertice[v] for v in verts]
        obrigatorio  = mask_deadline[ci]
        prox_ativa   = mask_ativa[ci + 1]   if ci + 1 < K else 0
        prox_entrada = mask_entrada[ci + 1] if ci + 1 < K else 0

        novo_dp = {}

        for estado, (custo, guardas_ate_agora) in dp.items():
            obrig_pendente = estado & obrigatorio

            for mask_g in range(1 << n):
                coberto = 0
                for j in range(n):
                    if (mask_g >> j) & 1:
                        coberto |= coberturas[j]
                coberto &= estado

                if (obrig_pendente & coberto) != obrig_pendente:
                    continue

                n_g = bin(mask_g).count('1')
                novo_custo = custo + n_g
                novo_estado = (estado & ~coberto & prox_ativa) | prox_entrada

                if novo_estado not in novo_dp or novo_custo < novo_dp[novo_estado][0]:
                    novos_g = guardas_ate_agora + [
                        verts[j] for j in range(n) if (mask_g >> j) & 1
                    ]
                    novo_dp[novo_estado] = (novo_custo, novos_g)

        if not novo_dp:
            return resolver_dp_heuristico(prob, faces)
        dp = novo_dp

    if 0 in dp:
        custo, guardas = dp[0]
        return sorted(guardas), int(custo)

    return resolver_dp_heuristico(prob, faces)


def resolver_dp_heuristico(prob, faces=None):
    # versão rápida: quando chega o deadline de uma face, cobre-a greedy
    if faces is None:
        faces = prob.obrigatorias

    (coords_x, verts_coluna, cob_vertice,
     mask_ativa, mask_entrada, mask_deadline) = _preparar_estruturas(prob, faces)

    guardas = set()
    coberto = 0

    for ci, x in enumerate(coords_x):
        obrig_pendente = mask_deadline[ci] & ~coberto
        if not obrig_pendente:
            continue

        while obrig_pendente:
            melhor_v = None
            melhor_score = -1

            for v in prob.vertices:
                ganho = bin(cob_vertice[v] & ~coberto).count('1')
                bonus = bin(cob_vertice[v] & obrig_pendente).count('1') * 100
                score = ganho + bonus
                if score > melhor_score:
                    melhor_score = score
                    melhor_v = v

            if melhor_v is None:
                break

            guardas.add(melhor_v)
            coberto |= cob_vertice[melhor_v]
            obrig_pendente &= ~coberto

    n_faces = len(faces)
    tudo = (1 << n_faces) - 1
    restante = tudo & ~coberto

    while restante:
        melhor_v = max(
            prob.vertices,
            key=lambda v: bin(cob_vertice[v] & restante).count('1')
        )
        if not (cob_vertice[melhor_v] & restante):
            break
        guardas.add(melhor_v)
        coberto |= cob_vertice[melhor_v]
        restante = tudo & ~coberto

    return sorted(guardas), len(guardas)
