def construir_grafo_conflito(prob, guardas, faces=None):
    # dois guardas conflituam se vigiarem a mesma face
    if faces is None:
        faces = prob.obrigatorias

    conflitos = {g: set() for g in guardas}

    for f in faces:
        gs_face = [g for g in guardas if f in prob.vertice_faces.get(g, set())]
        for i in range(len(gs_face)):
            for j in range(i + 1, len(gs_face)):
                g1, g2 = gs_face[i], gs_face[j]
                conflitos[g1].add(g2)
                conflitos[g2].add(g1)

    return conflitos


def colorir_greedy(grafo_conflito, guardas):
    # coloração Welsh-Powell: ordena por grau e atribui a cor mais baixa disponível
    ordenados = sorted(
        guardas,
        key=lambda g: len(grafo_conflito.get(g, set())),
        reverse=True
    )

    coloracao = {}
    for g in ordenados:
        cores_usadas = {coloracao[nb] for nb in grafo_conflito.get(g, set()) if nb in coloracao}
        cor = 1
        while cor in cores_usadas:
            cor += 1
        coloracao[g] = cor

    return coloracao


def resolver_com_cores(prob, faces=None):
    if faces is None:
        faces = prob.obrigatorias

    from ilp_ortools import resolver_ilp
    guardas, n_guardas = resolver_ilp(prob, faces)

    if guardas is None:
        return None, -1, -1

    conflito = construir_grafo_conflito(prob, guardas, faces)
    coloracao = colorir_greedy(conflito, guardas)
    n_cores = max(coloracao.values()) if coloracao else 0

    return coloracao, n_guardas, n_cores


def resolver_com_alcance(prob, D, faces=None, metodo='greedy'):
    # guarda em v vigia também vértices a distância <= D (extensão 4b)
    if faces is None:
        faces = prob.obrigatorias

    cobertura_d = {}
    for v in prob.vertices:
        vizinhos = prob.vizinhos_ate_distancia(v, D)
        cobertas = set()
        for u in vizinhos:
            cobertas |= prob.vertice_faces.get(u, set())
        cobertura_d[v] = cobertas & faces

    if metodo == 'ilp':
        from ortools.sat.python import cp_model
        model = cp_model.CpModel()
        x = {v: model.NewBoolVar(f"g_{v[0]}_{v[1]}") for v in prob.vertices}

        for f in faces:
            vigias = [v for v in prob.vertices if f in cobertura_d[v]]
            if vigias:
                model.AddBoolOr([x[v] for v in vigias])

        model.Minimize(sum(x[v] for v in prob.vertices))
        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = 30.0
        status = solver.Solve(model)

        if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            guardas = [v for v in prob.vertices if solver.Value(x[v]) == 1]
            return guardas, len(guardas)
        return None, -1

    else:
        por_cobrir = set(faces)
        guardas = []

        while por_cobrir:
            melhor = max(
                prob.vertices,
                key=lambda v: len(cobertura_d[v] & por_cobrir)
            )
            if not (cobertura_d[melhor] & por_cobrir):
                break
            guardas.append(melhor)
            por_cobrir -= cobertura_d[melhor]

        return guardas, len(guardas)


def comparar_alcances(prob, valores_D, faces=None):
    return {D: resolver_com_alcance(prob, D, faces)[1] for D in valores_D}
