import sys
import os
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from parser import ler_instancias
from problema import Problema


def nome_vertice(v):
    return f"v{v[0]}_{v[1]}"


def gerar_factos_prolog(prob, caminho_saida):
    with open(caminho_saida, 'w') as f:
        f.write(f"% {prob.n_faces} faces, {prob.n_vertices} vértices\n\n")

        for v in prob.vertices:
            f.write(f"vertice({nome_vertice(v)}).\n")

        f.write("\n")

        for id_face in prob.ids_faces:
            verts = prob.vertices_da_face(id_face)
            nomes = [nome_vertice(v) for v in verts]
            f.write(f"face({id_face}, [{', '.join(nomes)}]).\n")

    print(f"Escrito em '{caminho_saida}'  ({prob.n_faces} faces, {prob.n_vertices} vértices)")


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--ficheiro',  default='data/parts40.txt')
    ap.add_argument('--instancia', type=int, default=0)
    ap.add_argument('--saida',     default='prolog/instancia.pl')
    args = ap.parse_args()

    instancias = ler_instancias(args.ficheiro)
    prob = Problema(instancias[args.instancia])

    os.makedirs('prolog', exist_ok=True)
    gerar_factos_prolog(prob, args.saida)
