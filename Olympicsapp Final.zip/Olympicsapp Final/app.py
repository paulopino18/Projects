import warnings
warnings.filterwarnings("ignore", category=FutureWarning)
from flask import render_template, Flask, request
import logging
import db

APP = Flask(__name__)

# Página inicial
@APP.route('/')
def index():

    # Total de países
    total_paises = db.execute('''
        SELECT COUNT(*) AS total
        FROM Noc
    ''').fetchone()['total']

    # Total de atletas
    total_atletas = db.execute('''
        SELECT COUNT(*) AS total
        FROM Atleta
    ''').fetchone()['total']

    # Total de medalhas
    total_medalhas = db.execute('''
        SELECT COUNT(*) AS total
        FROM Participacao
    ''').fetchone()['total']

    # Atleta mais medalhado
    atleta_top = db.execute('''
        SELECT a.Nome,
               e.NomeEquipa,
               COUNT(pa.Medalha) AS TotalMedalhas
        FROM Participacao pa
        JOIN Atleta a ON a.IDAtleta = pa.IDAtleta
        JOIN Equipa e ON e.IDEquipa = a.IDEquipa
        GROUP BY a.IDAtleta
        ORDER BY TotalMedalhas DESC
        LIMIT 1
    ''').fetchone()

    # Atletas portugueses medalhados, por modalidade
    portugueses_medalhados = db.execute('''
        SELECT
            a.Nome           AS NomeAtleta,
            m.NomeDesporto   AS NomeDesporto,
            COUNT(p.Medalha) AS TotalMedalhas
        FROM PARTICIPACAO p
        JOIN ATLETA     a  ON a.IDAtleta   = p.IDAtleta
        JOIN EQUIPA     e  ON e.IDEquipa   = a.IDEquipa
        JOIN NOC        n  ON n.CodigoNOC  = e.CodigoNOC
        JOIN EVENTO     ev ON ev.IDEvento  = p.IDEvento
        JOIN MODALIDADE m  ON m.IDDesporto = ev.IDDesporto
        WHERE n.NomePais = 'Portugal'
        GROUP BY
            a.IDAtleta,
            a.Nome,
            m.IDDesporto,
            m.NomeDesporto
        ORDER BY
            TotalMedalhas DESC,
            a.Nome;
    ''').fetchall()

    # Top 5 países com mais medalhas
    top_paises = db.execute('''
        SELECT
            n.NomePais        AS NomePais,
            COUNT(pa.Medalha) AS TotalMedalhas
        FROM Participacao pa
        JOIN Atleta a ON a.IDAtleta   = pa.IDAtleta
        JOIN Equipa e ON e.IDEquipa   = a.IDEquipa
        JOIN NOC    n ON n.CodigoNOC  = e.CodigoNOC
        GROUP BY n.CodigoNOC, n.NomePais
        ORDER BY TotalMedalhas DESC
        LIMIT 5;
    ''').fetchall()

    # Top 10 modalidades com mais medalhas (para o gráfico)
    top_modalidades = db.execute('''
        SELECT
            m.NomeDesporto,
            COUNT(p.IDParticipacao) AS TotalMedalhas
        FROM PARTICIPACAO p
        JOIN EVENTO     e ON e.IDEvento   = p.IDEvento
        JOIN MODALIDADE m ON m.IDDesporto = e.IDDesporto
        GROUP BY m.IDDesporto, m.NomeDesporto
        ORDER BY TotalMedalhas DESC
        LIMIT 10;
    ''').fetchall()

    # listas para o Chart.js (modalidades)
    modal_labels = [row['NomeDesporto'] for row in top_modalidades]
    modal_values = [row['TotalMedalhas'] for row in top_modalidades]

    # Top 3 países com mais medalhas em cada edição dos Jogos
    top3_raw = db.execute('''
        SELECT
            j.IDJogos,
            j.NomeJogos,
            j.Ano,
            j.Cidade,
            n.NomePais,
            COUNT(p.Medalha) AS TotalMedalhas
        FROM PARTICIPACAO p
        JOIN ATLETA   a ON a.IDAtleta  = p.IDAtleta
        JOIN EQUIPA   e ON e.IDEquipa  = a.IDEquipa
        JOIN NOC      n ON n.CodigoNOC = e.CodigoNOC
        JOIN EVENTO  ev ON ev.IDEvento = p.IDEvento
        JOIN JOGOS    j ON j.IDJogos   = ev.IDJogos
        GROUP BY
            j.IDJogos, j.NomeJogos, j.Ano, j.Cidade, n.NomePais
        ORDER BY
            j.Ano, j.NomeJogos, TotalMedalhas DESC;
    ''').fetchall()

    # organizar em dicionário: {IDJogos: {info do jogo + lista top3}}
    top3_por_jogo = {}
    for row in top3_raw:
        jogo_id = row['IDJogos']

        if jogo_id not in top3_por_jogo:
            top3_por_jogo[jogo_id] = {
                'NomeJogos': row['NomeJogos'],
                'Ano':       row['Ano'],
                'Cidade':    row['Cidade'],
                'paises':    []
            }

        # só guardamos os 3 primeiros por jogo
        if len(top3_por_jogo[jogo_id]['paises']) < 3:
            top3_por_jogo[jogo_id]['paises'].append({
                'NomePais':      row['NomePais'],
                'TotalMedalhas': row['TotalMedalhas'],
            })

    # Top 10 atletas mais altos
    top_altos = db.execute('''
        SELECT
            Nome,
            Altura
        FROM ATLETA
        ORDER BY Altura DESC
        LIMIT 10;
    ''').fetchall()

    altos_labels = [row['Nome'] for row in top_altos]
    altos_values = [row['Altura'] for row in top_altos]


    # Distribuição de medalhas por país e modalidade na edição mais recente dos Jogos
    dist_raw = db.execute('''
        SELECT
            j.IDJogos,
            j.Ano,
            j.NomeJogos,
            j.Cidade,
            n.NomePais,
            m.NomeDesporto,
            COUNT(p.IDParticipacao) AS TotalMedalhas
        FROM PARTICIPACAO p
        JOIN ATLETA     a  ON a.IDAtleta   = p.IDAtleta
        JOIN EQUIPA     e  ON e.IDEquipa   = a.IDEquipa
        JOIN NOC        n  ON n.CodigoNOC  = e.CodigoNOC
        JOIN EVENTO     ev ON ev.IDEvento  = p.IDEvento
        JOIN JOGOS      j  ON j.IDJogos    = ev.IDJogos
        JOIN MODALIDADE m  ON m.IDDesporto = ev.IDDesporto
        WHERE
            j.Ano = (SELECT MAX(Ano) FROM JOGOS)
        GROUP BY
            j.IDJogos, j.Ano, j.NomeJogos, j.Cidade,
            n.NomePais, m.NomeDesporto
        ORDER BY
            TotalMedalhas DESC,
            n.NomePais,
            m.NomeDesporto;
    ''').fetchall()

    # organizar distribuição por jogo (na prática será só o último)
    dist_por_jogo = {}
    for row in dist_raw:
        jogo_id = row['IDJogos']
        if jogo_id not in dist_por_jogo:
            dist_por_jogo[jogo_id] = {
                'Ano':       row['Ano'],
                'NomeJogos': row['NomeJogos'],
                'Cidade':    row['Cidade'],
                'linhas':    []
            }
        dist_por_jogo[jogo_id]['linhas'].append({
            'NomePais':      row['NomePais'],
            'NomeDesporto':  row['NomeDesporto'],
            'TotalMedalhas': row['TotalMedalhas'],
        })

            # Top 10 combinações país–modalidade na última edição (para gráfico)
    top10_pairs = dist_raw[:10]  

    pairs_labels = [
        f"{row['NomePais']} - {row['NomeDesporto']}"
        for row in top10_pairs
    ]
    pairs_values = [row['TotalMedalhas'] for row in top10_pairs]


    return render_template(
        'index.html',
        total_paises=total_paises,
        total_atletas=total_atletas,
        total_medalhas=total_medalhas,
        atleta_top=atleta_top,
        top_paises=top_paises,
        modal_labels=modal_labels,
        modal_values=modal_values,
        top3_por_jogo=top3_por_jogo,
        altos_values=altos_values,
        altos_labels=altos_labels,
        portugueses_medalhados=portugueses_medalhados,
        dist_por_jogo=dist_por_jogo,
        pairs_labels=pairs_labels,    
        pairs_values=pairs_values,  
    )



@APP.route('/jogos')
def jogos():
    jogos = db.execute('''
        SELECT IDJogos, NomeJogos, Ano, Estacao, Cidade
        FROM JOGOS
        ORDER BY Ano DESC
    ''').fetchall()

    return render_template('jogos_list.html', jogos=jogos)

@APP.route('/paises')
def paises():
    q = request.args.get('q', '').strip()

    if q:
        # separar o que foi escrito em palavras: ex. "Costa Rica" -> ["Costa", "Rica"]
        te = q.split()

        # construir cláusulas tipo: NOC.NomePais LIKE ? AND NOC.NomePais LIKE ? ...
        where_clauses = ["NOC.NomePais LIKE ?" for _ in te]
        where_sql = " WHERE " + " AND ".join(where_clauses)

        sql = '''SELECT * FROM NOC''' + where_sql
        params = [f"%{t}%" for t in te]
        paises = db.execute(sql, params).fetchall()
    else:
        # sem pesquisa
        sql = '''SELECT * FROM NOC'''
        paises = db.execute(sql).fetchall()

    return render_template('paises_list.html', paises=paises, q=q)
    
@APP.route('/paises/<codigo>')
def pais(codigo):

    pais = db.execute('''
        SELECT CodigoNOC, NomePais
        FROM NOC
        WHERE CodigoNOC = ?
    ''', [codigo]).fetchone()

    atletas = db.execute('''
        SELECT ATLETA.IDAtleta, ATLETA.Nome, EQUIPA.NomeEquipa
        FROM ATLETA
        JOIN EQUIPA ON ATLETA.IDEquipa = EQUIPA.IDEquipa
        WHERE EQUIPA.CodigoNOC = ?
        ORDER BY ATLETA.Nome
    ''', [codigo]).fetchall()

    total = db.execute('''
    SELECT
        (SELECT COUNT(*) FROM PARTICIPACAO 
         JOIN ATLETA ON ATLETA.IDAtleta = PARTICIPACAO.IDAtleta
         JOIN EQUIPA ON EQUIPA.IDEquipa = ATLETA.IDEquipa
         WHERE EQUIPA.CodigoNOC = ? AND PARTICIPACAO.Medalha = 'Gold') AS Ouro,

        (SELECT COUNT(*) FROM PARTICIPACAO 
         JOIN ATLETA ON ATLETA.IDAtleta = PARTICIPACAO.IDAtleta
         JOIN EQUIPA ON EQUIPA.IDEquipa = ATLETA.IDEquipa
         WHERE EQUIPA.CodigoNOC = ? AND PARTICIPACAO.Medalha = 'Silver') AS Prata,

        (SELECT COUNT(*) FROM PARTICIPACAO 
         JOIN ATLETA ON ATLETA.IDAtleta = PARTICIPACAO.IDAtleta
         JOIN EQUIPA ON EQUIPA.IDEquipa = ATLETA.IDEquipa
         WHERE EQUIPA.CodigoNOC = ? AND PARTICIPACAO.Medalha = 'Bronze') AS Bronze,

        (SELECT COUNT(*) FROM PARTICIPACAO 
         JOIN ATLETA ON ATLETA.IDAtleta = PARTICIPACAO.IDAtleta
         JOIN EQUIPA ON EQUIPA.IDEquipa = ATLETA.IDEquipa
         WHERE EQUIPA.CodigoNOC = ?) AS Total;
''', [codigo, codigo, codigo, codigo]).fetchone()


    return render_template('pais.html',
        pais=pais,
        atletas=atletas,
        total=total)

@APP.route('/paises/<codigo>/medalhas')
def medalhas_pais(codigo):

    medalhas = db.execute('''
    SELECT 
    ATLETA.IDAtleta,
    ATLETA.Nome,
    EQUIPA.NomeEquipa,

    (SELECT COUNT(*) 
     FROM PARTICIPACAO 
     WHERE PARTICIPACAO.IDAtleta = ATLETA.IDAtleta 
       AND PARTICIPACAO.Medalha = 'Gold') AS Ouro,

    (SELECT COUNT(*) 
     FROM PARTICIPACAO 
     WHERE PARTICIPACAO.IDAtleta = ATLETA.IDAtleta 
       AND PARTICIPACAO.Medalha = 'Silver') AS Prata,

    (SELECT COUNT(*) 
     FROM PARTICIPACAO 
     WHERE PARTICIPACAO.IDAtleta = ATLETA.IDAtleta 
       AND PARTICIPACAO.Medalha = 'Bronze') AS Bronze,

    (SELECT COUNT(*) 
     FROM PARTICIPACAO 
     WHERE PARTICIPACAO.IDAtleta = ATLETA.IDAtleta) AS Total

FROM ATLETA
JOIN EQUIPA ON EQUIPA.IDEquipa = ATLETA.IDEquipa
WHERE EQUIPA.CodigoNOC = ?
ORDER BY Total DESC, ATLETA.Nome;


    ''', [codigo]).fetchall()

    return render_template('medalhas_pais.html',codigo=codigo,medalhas=medalhas)


@APP.route('/atletas')
def atletas():

    q = request.args.get('q', '').strip()
    if q:
        at = q.split()
        where_clauses = ["ATLETA.Nome LIKE ?" for _ in at]
        where_sql = " WHERE " + " AND ".join(where_clauses)

        sql = "SELECT IDAtleta, Nome FROM ATLETA" + where_sql + " ORDER BY Nome;"
        params = [f"%{t}%" for t in at]
        atletas = db.execute(sql, params).fetchall()
    else:
        sql = "SELECT IDAtleta, Nome FROM ATLETA ORDER BY Nome;"
        atletas = db.execute(sql).fetchall()

    return render_template('atletas_list.html', atletas=atletas, q=q)

@APP.route('/atletas/<int:id_atleta>')
def atleta_detalhe(id_atleta):
    atleta = db.execute('''
    SELECT
        a.Nome   AS NomeAtleta,
        a.Sexo   AS Sexo,
        a.Altura AS Altura,
        a.Peso   AS Peso,
        n.NomePais AS Pais,
        COALESCE(SUM(CASE WHEN p.Medalha = 'Gold'   THEN 1 ELSE 0 END), 0) AS MedalhasGold,
        COALESCE(SUM(CASE WHEN p.Medalha = 'Silver' THEN 1 ELSE 0 END), 0) AS MedalhasSilver,
        COALESCE(SUM(CASE WHEN p.Medalha = 'Bronze' THEN 1 ELSE 0 END), 0) AS MedalhasBronze,
        COUNT(p.Medalha) AS TotalMedalhas
    FROM ATLETA a
    JOIN EQUIPA e ON a.IDEquipa = e.IDEquipa
    JOIN NOC n    ON e.CodigoNOC = n.CodigoNOC
    LEFT JOIN PARTICIPACAO p
           ON a.IDAtleta = p.IDAtleta
          AND p.Medalha IS NOT NULL
    WHERE a.IDAtleta = ?
    GROUP BY
        a.IDAtleta,
        a.Nome,
        a.Sexo,
        a.Altura,
        a.Peso,
        n.NomePais;
''', (id_atleta,)).fetchone()

    return render_template('atleta_detail.html', atleta=atleta)

''' ---------- EVENTOS ---------- Edu, fiz a dos eventos quando clicas em eventos da uma lista de modalidades, clicas numa modalidade da te os eventos dessa modalidade, clicas num event dá te os vencedores
'''    

@APP.route('/modalidades')
def modalidades():
    q = request.args.get('q', '').strip()
    if q:
        s = q.split()
        where_clauses = ["m.NomeDesporto LIKE ?" for _ in s]
        where_sql = " WHERE " + " AND ".join(where_clauses)

        sql = "SELECT DISTINCT m.IDDesporto, m.NomeDesporto FROM MODALIDADE m JOIN EVENTO e ON e.IDDesporto = m.IDDesporto" + where_sql + " ORDER BY m.NomeDesporto;"
        params = [f"%{t}%" for t in s]
        modalidades = db.execute(sql, params).fetchall()
    else:
        sql = "SELECT DISTINCT m.IDDesporto, m.NomeDesporto FROM MODALIDADE m JOIN EVENTO e ON e.IDDesporto = m.IDDesporto ORDER BY m.NomeDesporto;"
        modalidades = db.execute(sql).fetchall()

    return render_template('eventos_list.html', modalidades=modalidades, q=q)


@APP.route('/modalidades/desporto/<int:id_desporto>')
def eventos_por_desporto(id_desporto):
    eventos = db.execute('''
        SELECT
            m.NomeDesporto,
            j.IDJogos,
            j.Ano,
            j.Cidade,
            j.NomeJogos,
            e.IDEvento,
            e.NomeEvento
        FROM EVENTO e
        JOIN MODALIDADE m ON e.IDDesporto = m.IDDesporto
        JOIN JOGOS j      ON e.IDJogos    = j.IDJogos
        WHERE e.IDDesporto = ?
        ORDER BY j.Ano, e.NomeEvento;
    ''', (id_desporto,)).fetchall()

    return render_template('eventos_por_desporto.html', eventos=eventos)


@APP.route('/modalidades/<int:id_evento>')
def evento_detalhe(id_evento):
    # informação base do evento
    evento = db.execute('''
        SELECT
            e.NomeEvento,
            m.NomeDesporto,
            j.Ano,
            j.Cidade,
            j.NomeJogos
        FROM EVENTO e
        JOIN MODALIDADE m ON e.IDDesporto = m.IDDesporto
        JOIN JOGOS j      ON e.IDJogos    = j.IDJogos
        WHERE e.IDEvento = ?;
    ''', (id_evento,)).fetchone()


    # medalhados por atleta
    resultados = db.execute('''
        SELECT
            a.Nome      AS NomeAtleta,
            n.NomePais  AS Pais,
            p.Medalha   AS Medalha
        FROM PARTICIPACAO p
        JOIN ATLETA a  ON a.IDAtleta  = p.IDAtleta
        JOIN EQUIPA eq ON eq.IDEquipa = a.IDEquipa
        JOIN NOC n     ON n.CodigoNOC = eq.CodigoNOC
        WHERE p.IDEvento = ?
          AND p.Medalha IN ('Gold', 'Silver', 'Bronze')
        ORDER BY CASE p.Medalha
                    WHEN 'Gold'   THEN 1
                    WHEN 'Silver' THEN 2
                    WHEN 'Bronze' THEN 3
                    ELSE 4
                 END;
    ''', (id_evento,)).fetchall()

    # medalhados por equipa (quando há várias atletas na mesma equipa)
    resultados_equipas = db.execute('''
        SELECT
            eq.NomeEquipa                      AS Equipa,
            n.NomePais                         AS Pais,
            p.Medalha                          AS Medalha,
            GROUP_CONCAT(a.Nome, ', ')         AS Atletas
        FROM PARTICIPACAO p
        JOIN ATLETA a  ON a.IDAtleta  = p.IDAtleta
        JOIN EQUIPA eq ON eq.IDEquipa = a.IDEquipa
        JOIN NOC n     ON n.CodigoNOC = eq.CodigoNOC
        WHERE p.IDEvento = ?
          AND p.Medalha IN ('Gold', 'Silver', 'Bronze')
        GROUP BY eq.IDEquipa, eq.NomeEquipa, n.NomePais, p.Medalha
        ORDER BY CASE p.Medalha
                    WHEN 'Gold'   THEN 1
                    WHEN 'Silver' THEN 2
                    WHEN 'Bronze' THEN 3
                    ELSE 4
                 END;
    ''', (id_evento,)).fetchall()

    return render_template(
        'evento_detail.html',
        evento=evento,
        resultados=resultados,
        resultados_equipas=resultados_equipas
    )

''' ------------PARTICIPAÇÕES----------------'''

@APP.route('/participacoes')
def participacoes():
    q = request.args.get('q', '').strip()

    base_sql = '''
        SELECT 
            eq.CodigoNOC,
            a.Nome,
            j.NomeJogos,
            e.NomeEvento,
            p.Medalha
        FROM PARTICIPACAO AS p  
        JOIN EVENTO  AS e ON e.IDEvento = p.IDEvento
        JOIN ATLETA  AS a ON a.IDAtleta = p.IDAtleta
        JOIN EQUIPA  AS eq ON eq.IDEquipa = a.IDEquipa
        JOIN JOGOS   AS j ON j.IDJogos   = e.IDJogos
    '''

    params = []

    if q:
        # separar o que foi escrito em palavras: ex. "telma monteiro" -> ["telma", "monteiro"]
        termos = q.split()

        # construir cláusulas tipo: a.Nome LIKE ? AND a.Nome LIKE ? ...
        where_clauses = ["a.Nome LIKE ?" for _ in termos]
        where_sql = " WHERE " + " AND ".join(where_clauses)

        sql = base_sql + where_sql + '''
            GROUP BY p.IDParticipacao, a.IDEquipa
            ORDER BY j.Ano, e.IDEvento, eq.CodigoNOC
        '''
        params = [f"%{t}%" for t in termos]
    else:
        # sem pesquisa: mostra tudo como antes
        sql = base_sql + '''
            GROUP BY p.IDParticipacao, a.IDEquipa
            ORDER BY j.Ano, e.IDEvento, eq.CodigoNOC
        '''

    participacoes = db.execute(sql, params).fetchall()

    return render_template(
        'participacoes.html',
        participacoes=participacoes,
        q=q
    )



@APP.route('/jogos/<int:id_jogos>')
def jogos_detail(id_jogos):
    # dados do jogo
    jogo = db.execute('''
        SELECT IDJogos, NomeJogos, Ano, Estacao, Cidade
        FROM JOGOS
        WHERE IDJogos = ?
    ''', [id_jogos]).fetchone()


    # eventos dessa edição
    eventos = db.execute('''
        SELECT e.IDEvento,
               e.NomeEvento,
               m.NomeDesporto,
               COUNT(p.IDParticipacao) AS NumParticipantes
        FROM EVENTO e
        JOIN MODALIDADE     m ON m.IDDesporto = e.IDDesporto
        LEFT JOIN PARTICIPACAO p ON p.IDEvento = e.IDEvento
        WHERE e.IDJogos = ?
        GROUP BY e.IDEvento, e.NomeEvento, m.NomeDesporto
        ORDER BY m.NomeDesporto, e.NomeEvento
    ''', [id_jogos]).fetchall()

    return render_template(
        'jogos_detail.html',
        jogo=jogo,
        eventos=eventos
    )