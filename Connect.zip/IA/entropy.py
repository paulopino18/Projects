"""
entropy.py
----------
Funções para calcular entropia de Shannon, entropia condicional,
ganho de informação e melhor threshold para atributos contínuos.

Usadas pelo algoritmo ID3 em id3.py.
"""

import numpy as np
from collections import Counter


# ──────────────────────────────────────────────
#  Entropia
# ──────────────────────────────────────────────

def entropy(y: np.ndarray) -> float:
    """
    Calcula a entropia de Shannon de um array de labels.

    H(Y) = - Σ p(c) * log2(p(c))

    Args:
        y: array de labels (classes)

    Returns:
        Valor de entropia em bits. Retorna 0.0 se y estiver vazio.
    """
    if len(y) == 0:
        return 0.0

    counts = Counter(y)
    total = len(y)

    return -sum(
        (count / total) * np.log2(count / total)
        for count in counts.values()
        if count > 0
    )


# ──────────────────────────────────────────────
#  Atributos Categóricos
# ──────────────────────────────────────────────

def conditional_entropy_categorical(X_col: np.ndarray, y: np.ndarray) -> float:
    """
    Calcula a entropia condicional H(Y | X) para um atributo categórico.

    H(Y|X) = Σ_v P(X=v) * H(Y | X=v)

    Args:
        X_col: coluna de features (valores categóricos)
        y:     array de labels correspondentes

    Returns:
        Entropia condicional em bits.
    """
    total = len(y)
    if total == 0:
        return 0.0

    cond_ent = 0.0
    for val in np.unique(X_col):
        mask = X_col == val
        subset_y = y[mask]
        cond_ent += (len(subset_y) / total) * entropy(subset_y)

    return cond_ent


def information_gain(X_col: np.ndarray, y: np.ndarray) -> float:
    """
    Calcula o ganho de informação para um atributo categórico.

    IG(Y, X) = H(Y) - H(Y|X)

    Args:
        X_col: coluna de features (valores categóricos)
        y:     array de labels

    Returns:
        Ganho de informação em bits (≥ 0).
    """
    return entropy(y) - conditional_entropy_categorical(X_col, y)


# ──────────────────────────────────────────────
#  Atributos Contínuos
# ──────────────────────────────────────────────

def information_gain_continuous(X_col: np.ndarray, y: np.ndarray, threshold: float) -> float:
    """
    Calcula o ganho de informação para um atributo contínuo com um dado threshold.

    Faz uma divisão binária: X <= threshold  vs  X > threshold.

    Args:
        X_col:     coluna de features (valores numéricos)
        y:         array de labels
        threshold: valor de corte

    Returns:
        Ganho de informação em bits.
    """
    mask = X_col <= threshold
    left_y  = y[mask]
    right_y = y[~mask]
    total   = len(y)

    if len(left_y) == 0 or len(right_y) == 0:
        return 0.0

    weighted_entropy = (
        (len(left_y)  / total) * entropy(left_y) +
        (len(right_y) / total) * entropy(right_y)
    )
    return entropy(y) - weighted_entropy


def best_threshold(X_col: np.ndarray, y: np.ndarray) -> tuple:
    """
    Encontra o melhor threshold para um atributo contínuo, maximizando o
    ganho de informação.

    Candidatos a threshold são os pontos médios entre valores consecutivos
    ordenados (abordagem padrão do C4.5 / ID3 contínuo).

    Args:
        X_col: coluna de features (valores numéricos)
        y:     array de labels

    Returns:
        Tuplo (best_threshold, best_gain).
        Se não houver threshold válido, retorna (None, 0.0).
    """
    sorted_unique = np.sort(np.unique(X_col.astype(float)))

    if len(sorted_unique) < 2:
        return None, 0.0

    # Candidatos: médias entre pares consecutivos
    candidates = (sorted_unique[:-1] + sorted_unique[1:]) / 2.0

    best_gain   = -1.0
    best_thresh = None

    for thresh in candidates:
        gain = information_gain_continuous(X_col.astype(float), y, thresh)
        if gain > best_gain:
            best_gain   = gain
            best_thresh = thresh

    return best_thresh, best_gain
