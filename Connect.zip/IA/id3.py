"""
id3.py
------
Implementação do algoritmo ID3 (Iterative Dichotomiser 3) de raiz,
sem uso de scikit-learn ou outras bibliotecas de ML.

Suporta:
  - Atributos categóricos  → split multi-way (um ramo por valor único)
  - Atributos contínuos    → split binário pelo melhor threshold
  - Profundidade máxima configurável
  - Poda por mínimo de amostras
  - Previsão com fallback para classe maioritária em valores não vistos

Uso:
    from id3 import ID3

    model = ID3(max_depth=5, continuous_features=['petal_length', 'petal_width'])
    model.fit(X_train, y_train, feature_names=['petal_length', ...])

    preds = model.predict(X_test)
    acc   = model.score(X_test, y_test)
"""

import numpy as np
from collections import Counter
from entropy import (
    entropy,
    information_gain,
    best_threshold,
    information_gain_continuous,
)


# ══════════════════════════════════════════════
#  Nó da árvore
# ══════════════════════════════════════════════

class DecisionNode:
    """
    Representa um nó na árvore de decisão ID3.

    Nó interno  : tem 'feature' definida e 'branches' populado.
    Nó folha    : tem 'label' definida (classe prevista).
    """

    __slots__ = (
        "feature", "feature_name", "threshold",
        "is_continuous", "branches", "label",
        "depth", "samples", "class_distribution",
    )

    def __init__(
        self,
        feature       = None,
        feature_name  = None,
        threshold     = None,
        is_continuous : bool = False,
        branches      : dict = None,
        label                = None,
        depth         : int  = 0,
        samples       : int  = 0,
        class_dist    : dict = None,
    ):
        self.feature           = feature
        self.feature_name      = feature_name
        self.threshold         = threshold
        self.is_continuous     = is_continuous
        self.branches          = branches if branches is not None else {}
        self.label             = label
        self.depth             = depth
        self.samples           = samples
        self.class_distribution = class_dist or {}

    def is_leaf(self) -> bool:
        return self.label is not None

    def __repr__(self):
        if self.is_leaf():
            return f"Leaf(label={self.label}, samples={self.samples})"
        if self.is_continuous:
            return (f"Node(feature={self.feature_name}, "
                    f"threshold={self.threshold:.4f}, depth={self.depth})")
        return f"Node(feature={self.feature_name}, depth={self.depth})"


# ══════════════════════════════════════════════
#  Algoritmo ID3
# ══════════════════════════════════════════════

class ID3:
    """
    Classificador ID3.

    Parâmetros:
        max_depth (int | None):
            Profundidade máxima da árvore. None = sem limite.
        min_samples_split (int):
            Nº mínimo de amostras para expandir um nó.
        continuous_features (list):
            Lista de nomes ou índices de features contínuas.
            Estas serão tratadas com split binário por threshold.
    """

    def __init__(
        self,
        max_depth           = None,
        min_samples_split   : int  = 2,
        continuous_features : list = None,
    ):
        self.max_depth            = max_depth
        self.min_samples_split    = min_samples_split
        self.continuous_features  = set(continuous_features or [])

        # Preenchido após fit()
        self.root          : DecisionNode = None
        self.feature_names : list         = []
        self.class_names   : list         = []
        self.n_features_   : int          = 0

    # ── Treino ───────────────────────────────

    def fit(self, X, y, feature_names: list = None):
        """
        Treina a árvore de decisão ID3.

        Args:
            X: array-like (n_samples, n_features) — pode ter valores categóricos ou numéricos
            y: array-like (n_samples,) — labels de classe
            feature_names: lista opcional de nomes das features

        Returns:
            self
        """
        X = np.array(X, dtype=object)
        y = np.array(y)

        n_samples, n_features = X.shape
        self.n_features_   = n_features
        self.class_names   = sorted(list(np.unique(y)))
        self.feature_names = (
            list(feature_names)
            if feature_names is not None
            else [f"feature_{i}" for i in range(n_features)]
        )

        # Normaliza continuous_features para um conjunto de índices inteiros
        self.continuous_features = self._normalize_cont_features()

        available = list(range(n_features))
        self.root = self._build(X, y, available, depth=0)
        return self

    def _normalize_cont_features(self) -> set:
        """Converte nomes/índices para índices inteiros."""
        result = set()
        for f in self.continuous_features:
            if isinstance(f, int):
                result.add(f)
            elif isinstance(f, str) and f in self.feature_names:
                result.add(self.feature_names.index(f))
        return result

    # ── Auxiliar ─────────────────────────────

    def _majority(self, y) -> object:
        """Devolve a classe maioritária num array de labels."""
        if len(y) == 0:
            return self.class_names[0] if self.class_names else None
        return Counter(y).most_common(1)[0][0]

    # ── Construção recursiva ─────────────────

    def _build(self, X, y, available_features: list, depth: int) -> DecisionNode:
        """Constrói recursivamente a árvore ID3."""
        n = len(y)
        class_dist = dict(Counter(y))
        majority   = self._majority(y)

        # ---- Casos base ----

        # 1. Todos os exemplos têm a mesma classe
        if len(np.unique(y)) == 1:
            return DecisionNode(
                label=y[0], depth=depth, samples=n, class_dist=class_dist
            )

        # 2. Sem features disponíveis
        if not available_features:
            return DecisionNode(
                label=majority, depth=depth, samples=n, class_dist=class_dist
            )

        # 3. Profundidade máxima atingida
        if self.max_depth is not None and depth >= self.max_depth:
            return DecisionNode(
                label=majority, depth=depth, samples=n, class_dist=class_dist
            )

        # 4. Poucas amostras para dividir
        if n < self.min_samples_split:
            return DecisionNode(
                label=majority, depth=depth, samples=n, class_dist=class_dist
            )

        # ---- Escolhe a melhor feature ----

        best_feat, best_thresh, best_gain = self._choose_feature(X, y, available_features)

        # Sem ganho positivo → folha
        if best_gain <= 1e-10:
            return DecisionNode(
                label=majority, depth=depth, samples=n, class_dist=class_dist
            )

        is_cont  = best_feat in self.continuous_features
        feat_name = self.feature_names[best_feat]

        node = DecisionNode(
            feature       = best_feat,
            feature_name  = feat_name,
            threshold     = best_thresh,
            is_continuous = is_cont,
            depth         = depth,
            samples       = n,
            class_dist    = class_dist,
        )

        # ---- Divide os dados ----

        if is_cont:
            self._split_continuous(node, X, y, best_feat, best_thresh, available_features, depth)
        else:
            new_available = [f for f in available_features if f != best_feat]
            self._split_categorical(node, X, y, best_feat, new_available, depth, majority, class_dist)

        return node

    def _split_continuous(self, node, X, y, feat_idx, threshold, available_features, depth):
        """Cria ramos para split binário (contínuo)."""
        col  = X[:, feat_idx].astype(float)
        mask = col <= threshold

        for branch_mask, branch_key in [(mask, f"<= {threshold:.4f}"),
                                         (~mask, f"> {threshold:.4f}")]:
            sub_X = X[branch_mask]
            sub_y = y[branch_mask]

            if len(sub_y) == 0:
                # Ramo vazio → folha com classe maioritária do pai
                node.branches[branch_key] = DecisionNode(
                    label    = self._majority(y),
                    depth    = depth + 1,
                    samples  = 0,
                    class_dist = {},
                )
            else:
                # Features contínuas continuam disponíveis (o threshold pode ser diferente)
                node.branches[branch_key] = self._build(sub_X, sub_y, available_features, depth + 1)

    def _split_categorical(self, node, X, y, feat_idx, available_features, depth, majority, class_dist):
        """Cria um ramo por valor único da feature categórica."""
        unique_vals = np.unique(X[:, feat_idx])

        for val in unique_vals:
            mask  = X[:, feat_idx] == val
            sub_X = X[mask]
            sub_y = y[mask]

            if len(sub_y) == 0:
                node.branches[val] = DecisionNode(
                    label      = majority,
                    depth      = depth + 1,
                    samples    = 0,
                    class_dist = {},
                )
            else:
                node.branches[val] = self._build(sub_X, sub_y, available_features, depth + 1)

    # ── Seleção de feature ───────────────────

    def _choose_feature(self, X, y, available_features):
        """
        Avalia todas as features disponíveis e devolve a de maior ganho de informação.

        Returns:
            (feat_idx, threshold_or_None, gain)
        """
        best_gain   = -1.0
        best_feat   = None
        best_thresh = None

        for feat_idx in available_features:
            is_cont = feat_idx in self.continuous_features

            if is_cont:
                col = X[:, feat_idx].astype(float)
                thresh, gain = best_threshold(col, y)
                if thresh is None:
                    continue
            else:
                col    = X[:, feat_idx]
                gain   = information_gain(col, y)
                thresh = None

            if gain > best_gain:
                best_gain   = gain
                best_feat   = feat_idx
                best_thresh = thresh

        return best_feat, best_thresh, best_gain

    # ── Previsão ─────────────────────────────

    def predict(self, X):
        """
        Prevê as classes para um conjunto de amostras.

        Args:
            X: array-like (n_samples, n_features) ou (n_features,) para uma só amostra

        Returns:
            np.ndarray de labels previstos.
        """
        if self.root is None:
            raise RuntimeError("Modelo não treinado. Chama fit() primeiro.")

        X = np.array(X, dtype=object)
        if X.ndim == 1:
            return self._traverse(X, self.root)
        return np.array([self._traverse(x, self.root) for x in X])

    def _traverse(self, x, node: DecisionNode):
        """Percorre a árvore para classificar uma amostra."""
        if node.is_leaf():
            return node.label

        val = x[node.feature]

        if node.is_continuous and node.threshold is not None:
            try:
                fval = float(val)
                branch_key = f"<= {node.threshold:.4f}" if fval <= node.threshold else f"> {node.threshold:.4f}"
            except (ValueError, TypeError):
                # Valor não numérico inesperado → classe maioritária
                return self._most_common_leaf(node)
        else:
            branch_key = val

        if branch_key in node.branches:
            return self._traverse(x, node.branches[branch_key])

        # Valor não visto em treino → retorna classe maioritária da subárvore
        return self._most_common_leaf(node)

    def _most_common_leaf(self, node: DecisionNode):
        """
        Fallback: retorna a classe maioritária entre as folhas alcançáveis a partir de 'node'.
        """
        if node.is_leaf():
            return node.label
        if node.class_distribution:
            return max(node.class_distribution, key=node.class_distribution.get)
        # Percorre o primeiro ramo disponível
        for child in node.branches.values():
            return self._most_common_leaf(child)
        return self.class_names[0] if self.class_names else None

    # ── Avaliação ────────────────────────────

    def score(self, X, y) -> float:
        """
        Calcula a accuracy do modelo.

        Returns:
            float entre 0.0 e 1.0
        """
        predictions = self.predict(X)
        return float(np.mean(predictions == np.array(y)))

    def confusion_matrix(self, X, y) -> dict:
        """
        Calcula a matriz de confusão.

        Returns:
            dict {true_label: {pred_label: count}}
        """
        preds = self.predict(X)
        y     = np.array(y)
        cm    = {c: {c2: 0 for c2 in self.class_names} for c in self.class_names}

        for true, pred in zip(y, preds):
            if true in cm and pred in cm[true]:
                cm[true][pred] += 1

        return cm

    def classification_report(self, X, y) -> str:
        """
        Devolve um relatório de classificação simples (precision, recall, f1 por classe).
        """
        preds = self.predict(X)
        y     = np.array(y)
        lines = [f"{'Class':<20} {'Precision':>10} {'Recall':>10} {'F1':>10} {'Support':>10}"]
        lines.append("-" * 55)

        for cls in self.class_names:
            tp = np.sum((y == cls) & (preds == cls))
            fp = np.sum((y != cls) & (preds == cls))
            fn = np.sum((y == cls) & (preds != cls))

            precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
            recall    = tp / (tp + fn) if (tp + fn) > 0 else 0.0
            f1        = (2 * precision * recall / (precision + recall)
                         if (precision + recall) > 0 else 0.0)
            support   = int(np.sum(y == cls))

            lines.append(f"{str(cls):<20} {precision:>10.3f} {recall:>10.3f} {f1:>10.3f} {support:>10}")

        lines.append("-" * 55)
        acc = float(np.mean(preds == y))
        lines.append(f"\nAccuracy: {acc:.4f}  ({int(np.sum(preds == y))}/{len(y)})")
        return "\n".join(lines)

    # ── Estatísticas ─────────────────────────

    def get_depth(self) -> int:
        """Devolve a profundidade real da árvore."""
        return self._depth(self.root)

    def _depth(self, node) -> int:
        if node is None or node.is_leaf():
            return 0
        return 1 + max(self._depth(c) for c in node.branches.values())

    def get_n_leaves(self) -> int:
        """Devolve o número de nós folha."""
        return self._count_leaves(self.root)

    def _count_leaves(self, node) -> int:
        if node is None:
            return 0
        if node.is_leaf():
            return 1
        return sum(self._count_leaves(c) for c in node.branches.values())

    def get_n_nodes(self) -> int:
        """Devolve o número total de nós (internos + folhas)."""
        return self._count_nodes(self.root)

    def _count_nodes(self, node) -> int:
        if node is None:
            return 0
        return 1 + sum(self._count_nodes(c) for c in node.branches.values())

    def tree_stats(self) -> dict:
        """Devolve um dict com estatísticas da árvore."""
        return {
            "depth"   : self.get_depth(),
            "n_leaves": self.get_n_leaves(),
            "n_nodes" : self.get_n_nodes(),
        }

    # ── Serialização ─────────────────────────

    def to_dict(self) -> dict:
        """Serializa a árvore para um dicionário (útil para debug/export)."""
        return self._node_to_dict(self.root)

    def _node_to_dict(self, node) -> dict:
        if node is None:
            return {}
        if node.is_leaf():
            return {
                "type"   : "leaf",
                "class"  : str(node.label),
                "samples": node.samples,
                "dist"   : {str(k): v for k, v in node.class_distribution.items()},
            }
        d = {
            "type"         : "node",
            "feature"      : node.feature_name,
            "is_continuous": node.is_continuous,
            "threshold"    : node.threshold,
            "depth"        : node.depth,
            "samples"      : node.samples,
            "branches"     : {
                str(val): self._node_to_dict(child)
                for val, child in node.branches.items()
            },
        }
        return d

    def __repr__(self):
        if self.root is None:
            return "ID3(not fitted)"
        stats = self.tree_stats()
        return (f"ID3(depth={stats['depth']}, "
                f"leaves={stats['n_leaves']}, "
                f"nodes={stats['n_nodes']}, "
                f"max_depth={self.max_depth})")
