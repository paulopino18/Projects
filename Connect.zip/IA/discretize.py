"""
discretize.py
-------------
Funções para discretizar atributos contínuos (necessário para o dataset Iris).

Estratégias disponíveis:
  - equal_width  : intervalos de largura igual
  - equal_freq   : intervalos de frequência igual (quantis)
  - entropy_based: divisão que maximiza o ganho de informação (melhor para ID3)

O objeto `Discretizer` é treinado nos dados de treino e depois aplicado
aos dados de teste, garantindo que os bins sejam consistentes.
"""

import numpy as np
import pandas as pd
from collections import defaultdict


# ──────────────────────────────────────────────
#  Funções auxiliares de binning
# ──────────────────────────────────────────────

def _bin_label(col_name: str, bin_idx: int, edges: np.ndarray) -> str:
    """Gera um label descritivo para um bin. Ex: 'petal_length (1.00, 3.45]'"""
    lo = f"{edges[bin_idx]:.2f}"
    hi = f"{edges[bin_idx + 1]:.2f}"
    return f"{col_name} ({lo}, {hi}]"


def _apply_edges(values: np.ndarray, edges: np.ndarray, col_name: str) -> np.ndarray:
    """
    Aplica bordas de bins pré-calculadas a um array de valores.

    Args:
        values:   array numérico
        edges:    bordas dos bins (tamanho n_bins + 1)
        col_name: nome da coluna (usado nos labels)

    Returns:
        Array de strings com os labels dos bins.
    """
    n_bins = len(edges) - 1
    result = np.empty(len(values), dtype=object)

    for i, v in enumerate(values):
        placed = False
        for b in range(n_bins):
            lo = edges[b]
            hi = edges[b + 1]
            # Primeiro bin inclui o mínimo; restantes são (lo, hi]
            if b == 0 and lo <= v <= hi:
                result[i] = _bin_label(col_name, b, edges)
                placed = True
                break
            elif lo < v <= hi:
                result[i] = _bin_label(col_name, b, edges)
                placed = True
                break
        if not placed:
            # Valor fora de range (dados de teste) → bin mais próximo
            if v <= edges[0]:
                result[i] = _bin_label(col_name, 0, edges)
            else:
                result[i] = _bin_label(col_name, n_bins - 1, edges)

    return result


# ──────────────────────────────────────────────
#  Classe principal: Discretizer
# ──────────────────────────────────────────────

class Discretizer:
    """
    Discretizador treinável para colunas numéricas.

    Uso típico:
        disc = Discretizer(method='equal_width', n_bins=3)
        X_train_disc = disc.fit_transform(X_train_df, columns=['petal_length', ...])
        X_test_disc  = disc.transform(X_test_df)

    Atributos após fit:
        bin_edges_  : dict {coluna: np.ndarray de edges}
        columns_    : lista de colunas discretizadas
    """

    METHODS = ('equal_width', 'equal_freq', 'entropy_based')

    def __init__(self, method: str = 'equal_width', n_bins: int = 3):
        """
        Args:
            method: estratégia de binning ('equal_width', 'equal_freq', 'entropy_based')
            n_bins: número de bins (ignorado em 'entropy_based' — determinado pelos dados)
        """
        if method not in self.METHODS:
            raise ValueError(f"method deve ser um de {self.METHODS}")

        self.method   = method
        self.n_bins   = n_bins
        self.bin_edges_: dict = {}
        self.columns_: list   = []

    # ── Fit ──────────────────────────────────

    def fit(self, df: pd.DataFrame, columns: list, y: np.ndarray = None):
        """
        Aprende os bins a partir dos dados de treino.

        Args:
            df:      DataFrame com os dados de treino
            columns: lista de nomes de colunas a discretizar
            y:       labels (necessário apenas para 'entropy_based')

        Returns:
            self (para encadeamento)
        """
        self.columns_ = columns

        for col in columns:
            values = df[col].values.astype(float)

            if self.method == 'equal_width':
                edges = np.linspace(values.min(), values.max(), self.n_bins + 1)

            elif self.method == 'equal_freq':
                quantiles = np.linspace(0, 100, self.n_bins + 1)
                edges     = np.percentile(values, quantiles)
                edges     = np.unique(edges)  # remove duplicados

            elif self.method == 'entropy_based':
                if y is None:
                    raise ValueError("'entropy_based' requer o argumento y (labels).")
                edges = self._entropy_based_edges(values, y)

            # Garante que o mínimo e máximo cobrem os dados de treino
            edges[0]  = values.min() - 1e-9
            edges[-1] = values.max() + 1e-9

            self.bin_edges_[col] = edges

        return self

    def _entropy_based_edges(self, values: np.ndarray, y: np.ndarray) -> np.ndarray:
        """
        Calcula edges usando divisões recursivas que maximizam o ganho de informação.
        Aproximação do algoritmo MDLP (Fayyad & Irani, 1993).

        Returns:
            Array de edges.
        """
        from entropy import best_threshold  # importação local para evitar ciclos

        edges = set()
        self._recursive_split(values, y, edges, max_depth=4)

        sorted_edges = sorted(edges)
        if not sorted_edges:
            return np.array([values.min(), values.max()])

        return np.array([values.min()] + sorted_edges + [values.max()])

    def _recursive_split(self, values, y, edges, depth):
        """Divisão recursiva por ganho de informação."""
        from entropy import best_threshold

        if depth == 0 or len(np.unique(y)) <= 1 or len(values) < 4:
            return

        thresh, gain = best_threshold(values, y)

        if thresh is None or gain <= 0:
            return

        edges.add(thresh)

        mask = values <= thresh
        self._recursive_split(values[mask],  y[mask],  edges, depth - 1)
        self._recursive_split(values[~mask], y[~mask], edges, depth - 1)

    # ── Transform ────────────────────────────

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Aplica a discretização aprendida a um DataFrame.

        Args:
            df: DataFrame (pode ser treino ou teste)

        Returns:
            Novo DataFrame com as colunas especificadas discretizadas.
        """
        if not self.bin_edges_:
            raise RuntimeError("Chama fit() antes de transform().")

        df_out = df.copy()
        for col in self.columns_:
            edges  = self.bin_edges_[col]
            values = df_out[col].values.astype(float)
            df_out[col] = _apply_edges(values, edges, col)

        return df_out

    def fit_transform(self, df: pd.DataFrame, columns: list, y: np.ndarray = None) -> pd.DataFrame:
        """Atalho para fit() seguido de transform()."""
        self.fit(df, columns, y)
        return self.transform(df)

    # ── Utilitários ──────────────────────────

    def summary(self) -> None:
        """Imprime um resumo dos bins aprendidos."""
        if not self.bin_edges_:
            print("Discretizer ainda não treinado.")
            return

        print(f"Discretizer  method={self.method}  n_bins={self.n_bins}")
        print("-" * 50)
        for col, edges in self.bin_edges_.items():
            n = len(edges) - 1
            print(f"  {col}  →  {n} bins")
            for i in range(n):
                print(f"      bin {i+1}: ({edges[i]:.4f}, {edges[i+1]:.4f}]")
        print("-" * 50)
