import pygame
import sys
import numpy as np
import random
import math
from Connect4 import create_board, jogada, jogada_possivel, board_full, won
from id3 import classificar, carregar_dataset, id3

# Constantes
ROWS = 6
COLS = 7
SQUARESIZE = 100
RADIUS = int(SQUARESIZE / 2 - 5)
WIDTH = COLS * SQUARESIZE
HEIGHT = (ROWS + 2) * SQUARESIZE
SIZE = (WIDTH, HEIGHT)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
FPS = 60

def random_bot(board):
    moves = [i for i, x in enumerate(jogada_possivel(board)) if x == 1]
    return random.choice(moves)

def id3_bot(board, arvore):
    estado = board.flatten().astype(int)
    return int(classificar(estado, arvore))

def mcts_bot(player, board, iteracoes=300, c=math.sqrt(2)):
    class Node:
        def __init__(self, board, player, parent=None):
            self.board = board
            self.player = player
            self.parent = parent
            self.children = {}
            self.visits = 0
            self.wins = 0

        def uct(self, total_visits):
            if self.visits == 0:
                return float('inf')
            return (self.wins / self.visits) + c * math.sqrt(math.log(total_visits) / self.visits)

    def simulate(node):
        sim_board = np.copy(node.board)
        sim_player = node.player
        while not board_full(sim_board) and not won(sim_board, sim_player) and not won(sim_board, -sim_player):
            moves = [i for i, x in enumerate(jogada_possivel(sim_board)) if x == 1]
            move = random.choice(moves)
            sim_board = jogada(sim_board, sim_player, move)
            sim_player *= -1
        return 1 if won(sim_board, player) else 0

    root = Node(board, player)
    for _ in range(iteracoes):
        node = root
        path = [node]
        while node.children:
            best = max(node.children.items(), key=lambda x: x[1].uct(node.visits))[0]
            node = node.children[best]
            path.append(node)
        if not board_full(node.board) and not won(node.board, node.player):
            moves = [i for i, x in enumerate(jogada_possivel(node.board)) if x == 1]
            for move in moves:
                new_board = jogada(node.board, node.player, move)
                node.children[move] = Node(new_board, -node.player, node)
        result = simulate(node)
        for n in path:
            n.visits += 1
            n.wins += result
    best_move = max(root.children.items(), key=lambda x: x[1].visits)[0]
    return best_move

def show_menu(screen):
    font = pygame.font.SysFont("monospace", 40)
    screen.fill(BLACK)
    title = font.render("Escolha o modo e dificuldade", 1, WHITE)
    screen.blit(title, (40, 50))
    screen.blit(font.render("1. PvP", 1, WHITE), (40, 150))
    screen.blit(font.render("2. PvBot - Fácil", 1, WHITE), (40, 220))
    screen.blit(font.render("3. PvBot - Médio", 1, WHITE), (40, 290))
    screen.blit(font.render("4. PvBot - Difícil", 1, WHITE), (40, 360))
    pygame.display.update()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1: return 'PvP', None
                if event.key == pygame.K_2: return 'PvBot', 'easy'
                if event.key == pygame.K_3: return 'PvBot', 'medium'
                if event.key == pygame.K_4: return 'PvBot', 'hard'

def draw_board(screen, board):
    for c in range(COLS):
        for r in range(ROWS):
            pygame.draw.rect(screen, BLUE, (c*SQUARESIZE, (r+2)*SQUARESIZE, SQUARESIZE, SQUARESIZE))
            color = BLACK
            if board[r][c] == 1:
                color = RED
            elif board[r][c] == -1:
                color = YELLOW
            pygame.draw.circle(screen, color, (int(c*SQUARESIZE + SQUARESIZE/2), int((r+2)*SQUARESIZE + SQUARESIZE/2)), RADIUS)
    pygame.display.update()

def main():
    pygame.init()
    screen = pygame.display.set_mode(SIZE)
    pygame.display.set_caption("Connect 4")
    clock = pygame.time.Clock()

    mode, difficulty = show_menu(screen)
    board = create_board()
    draw_board(screen, board)
    font = pygame.font.SysFont("monospace", 50)
    turn = 0
    game_over = False

    if difficulty == 'easy':
        bot_func = random_bot
    elif difficulty == 'medium':
        dados = carregar_dataset("dataset.csv")
        atributos = list(range(len(dados[0]) - 1))
        arvore = id3(dados, atributos)
        bot_func = lambda board: id3_bot(board, arvore)
    elif difficulty == 'hard':
        bot_func = lambda board: mcts_bot(-1, board)

    while not game_over:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if mode == 'PvP' or (mode == 'PvBot' and turn == 0):
                if event.type == pygame.MOUSEBUTTONDOWN:
                    x = event.pos[0] // SQUARESIZE
                    if jogada_possivel(board)[x]:
                        board = jogada(board, 1 if turn == 0 else -1, x)
                        draw_board(screen, board)
                        if won(board, 1 if turn == 0 else -1):
                            vencedor = "Jogador 1" if turn == 0 else "Jogador 2"
                            pygame.draw.rect(screen, BLACK, (0, 0, WIDTH, SQUARESIZE*2))
                            label = font.render(f"{vencedor} venceu! (R para reiniciar)", True, RED)
                            screen.blit(label, (40, 10))
                            pygame.display.update()
                            game_over = True
                        turn ^= 1
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r and game_over:
                return  # Reiniciar

        if not game_over and mode == 'PvBot' and turn == 1:
            pygame.time.wait(500)
            col = bot_func(board)
            if jogada_possivel(board)[col]:
                board = jogada(board, -1, col)
                draw_board(screen, board)
                if won(board, -1):
                    pygame.draw.rect(screen, BLACK, (0, 0, WIDTH, SQUARESIZE*2))
                    label = font.render("Bot venceu! (R para reiniciar)", True, YELLOW)
                    screen.blit(label, (40, 10))
                    pygame.display.update()
                    game_over = True
                turn ^= 1

        if board_full(board) and not game_over:
            pygame.draw.rect(screen, BLACK, (0, 0, WIDTH, SQUARESIZE*2))
            label = font.render("Empate! (R para reiniciar)", True, WHITE)
            screen.blit(label, (40, 10))
            pygame.display.update()
            game_over = True

        clock.tick(FPS)

if __name__ == '__main__':
    main()
