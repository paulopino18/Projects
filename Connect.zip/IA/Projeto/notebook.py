import numpy as np
import copy
import math
import time
import csv
import random

# ====== Logica do Jogo Connect Four ======

def create_board():
    # Cria o tabuleiro vazio (6 linhas x 7 colunas)
    return np.zeros((6, 7))

def jogada_possivel(board):
    # Verifica se ha espaco em cada coluna (1 = possivel, 0 = cheia)
    return [1 if sum(board[:, col] == 0) > 0 else 0 for col in range(7)]

def jogada(board, player, col):
    # Realiza a jogada do jogador na coluna especificada
    tab = copy.deepcopy(board)
    if jogada_possivel(tab)[col] == 0:
        raise Exception("Jogada impossivel!")
    row = sum(tab[:, col] == 0) - 1
    tab[row, col] = player
    return tab

def board_full(board):
    # Verifica se o tabuleiro esta completamente cheio
    return sum(board.flatten() == 0) == 0

def won(board, player):
    # Verifica se o jogador venceu (4 em linha)
    # Vertical
    for col in range(7):
        for row in range(3):
            if all(board[row+i, col] == player for i in range(4)):
                return True
    # Horizontal
    for row in range(6):
        for col in range(4):
            if all(board[row, col+i] == player for i in range(4)):
                return True
    # Diagonal
    for row in range(3):
        for col in range(4):
            if all(board[row+i, col+i] == player for i in range(4)):
                return True
    # Diagonal2
    for row in range(3, 6):
        for col in range(4):
            if all(board[row-i, col+i] == player for i in range(4)):
                return True
    return False

# ====== Monte Carlo Tree Search (MCTS) ======

class MCTSNode:
    def __init__(self, state, player, parent=None, parent_action=None):
        # Inicializa um nó da árvore de busca MCTS
        self.state = state
        self.parent = parent
        self.parent_action = parent_action
        self.children = []
        self._number_of_visits = 0
        self.q = 0
        self._untried_actions = self.untried_actions()
        self.player = player

    def untried_actions(self):
        # Lista de ações ainda não exploradas a partir do nó
        possible = jogada_possivel(self.state)
        return [col for col in range(7) if possible[col] == 1]

    def n(self):
        return self._number_of_visits

    def expand(self):
        # Expande a árvore escolhendo uma ação não explorada
        action = self._untried_actions.pop()
        next_state = jogada(self.state, self.player, action)
        child_node = MCTSNode(next_state, -self.player, parent=self, parent_action=action)
        self.children.append(child_node)
        return child_node

    def is_terminal_node(self):
        # Verifica se o nó é terminal (fim de jogo)
        return won(self.state, self.player) or won(self.state, -self.player) or board_full(self.state)

    def rollout(self):
        # Simula uma partida aleatória a partir do estado atual
        current_state = np.copy(self.state)
        current_player = self.player
        while not won(current_state, current_player) and not won(current_state, -current_player) and not board_full(current_state):
            possible = jogada_possivel(current_state)
            available = [col for col in range(7) if possible[col] == 1]
            action = np.random.choice(available)
            current_state = jogada(current_state, current_player, action)
            current_player *= -1
        return self.game_result(current_state)

    def backpropagate(self, result):
        # Propaga o resultado da simulação de volta até a raiz
        current = self
        while current is not None:
            current._number_of_visits += 1
            if result == current.player:
                current.q += 1
            elif result == 0:
                current.q += 0.5
            current = current.parent

    def is_fully_expanded(self):
        return len(self._untried_actions) == 0

    def best_child(self, c):
        # Seleciona o melhor filho usando UCT (exploração vs. exploração)
        best_score = float('-inf')
        best_child = None
        for child in self.children:
            if child.n() == 0:
                return child
            exploitation = child.q / child.n()
            exploration = c * math.sqrt(math.log(self.n()) / child.n())
            score = exploitation + exploration
            if score > best_score:
                best_score = score
                best_child = child
        return best_child

    def _tree_policy(self):
        # Caminha na árvore até encontrar um nó para expandir
        current_node = self
        while not current_node.is_terminal_node():
            if not current_node.is_fully_expanded():
                return current_node.expand()
            else:
                current_node = current_node.best_child(math.sqrt(2))
        return current_node

    def best_action(self, time_limit, c):
        # Executa MCTS por um tempo determinado
        start_time = time.process_time()
        while time.process_time() - start_time < time_limit:
            v = self._tree_policy()
            reward = v.rollout()
            v.backpropagate(reward)
        return self.most_visited_child().parent_action

    def most_visited_child(self):
        # Retorna o filho mais visitado (mais confiavel)
        return max(self.children, key=lambda child: child.n())

    def game_result(self, board):
        if won(board, 1): return 1
        elif won(board, -1): return -1
        return 0

def bot_mcts(player, board, constant=math.sqrt(2)):
    # Cria o bot MCTS e retorna a melhor jogada
    root = MCTSNode(copy.deepcopy(board), player)
    return root.best_action(1, constant)

# ====== ID3 - Decision Tree ======

class NoID3:
    def __init__(self, atributo=None, filhos=None, classe=None):
        self.atributo = atributo
        self.filhos = filhos if filhos is not None else {}
        self.classe = classe

def entropia(exemplos):
    # Calcula a entropia de um conjunto de exemplos
    total = len(exemplos)
    if total == 0: return 0
    contagens = {}
    for exemplo in exemplos:
        classe = exemplo[-1]
        contagens[classe] = contagens.get(classe, 0) + 1
    return -sum((c/total) * math.log2(c/total) for c in contagens.values())

def dividir(exemplos, atributo):
    # Divide o conjunto de exemplos por um atributo
    resultado = {}
    for ex in exemplos:
        chave = ex[atributo]
        resultado.setdefault(chave, []).append(ex)
    return resultado

def ganho_informacao(exemplos, atributo):
    # Calcula o ganho de informação ao dividir pelo atributo
    entropia_total = entropia(exemplos)
    divisao = dividir(exemplos, atributo)
    total = len(exemplos)
    entropia_atributo = sum((len(sub)/total) * entropia(sub) for sub in divisao.values())
    return entropia_total - entropia_atributo

def id3(exemplos, atributos):
    # Algoritmo recursivo ID3 para construir a árvore
    classes = [ex[-1] for ex in exemplos]
    if all(c == classes[0] for c in classes):
        return NoID3(classe=classes[0])
    if not atributos:
        majoritaria = max(set(classes), key=classes.count)
        return NoID3(classe=majoritaria)
    melhor = max(atributos, key=lambda a: ganho_informacao(exemplos, a))
    raiz = NoID3(atributo=melhor)
    divisao = dividir(exemplos, melhor)
    for valor, subconj in divisao.items():
        if not subconj:
            raiz.filhos[valor] = NoID3(classe=max(set(classes), key=classes.count))
        else:
            novos_atributos = [a for a in atributos if a != melhor]
            raiz.filhos[valor] = id3(subconj, novos_atributos)
    return raiz

def classificar(exemplo, arvore):
    # Classifica um novo exemplo usando a árvore ID3
    while arvore.classe is None:
        valor = exemplo[arvore.atributo]
        arvore = arvore.filhos.get(valor)
        if arvore is None:
            return None
    return arvore.classe

def carregar_dataset(ficheiro):
    # Carrega o dataset salvo em CSV
    with open(ficheiro, "r") as f:
        return [list(map(int, linha)) for linha in csv.reader(f)]

def avaliar_id3(dados, proporcao_treino=0.8):
    # Avalia o desempenho da árvore em dados de treino/teste
    random.shuffle(dados)
    n = int(len(dados) * proporcao_treino)
    treino, teste = dados[:n], dados[n:]
    atributos = list(range(len(dados[0]) - 1))
    arvore = id3(treino, atributos)
    corretos = sum(1 for ex in teste if classificar(ex, arvore) == ex[-1])
    acc = corretos / len(teste)
    print(f"Acurácia: {acc:.2%}")
    return arvore

def gerar_data(n_jogos=500, ficheiro_saida="dataset.csv"):
    # Gera um dataset com partidas jogadas pelo MCTS
    dados = []
    for _ in range(n_jogos):
        board = create_board()
        jogador = 1
        while not board_full(board) and not won(board, jogador) and not won(board, -jogador):
            estado = board.flatten().astype(int)
            jogada_feita = bot_mcts(jogador, board, math.sqrt(2))
            dados.append(np.append(estado, jogada_feita))
            board = jogada(board, jogador, jogada_feita)
            jogador *= -1
    with open(ficheiro_saida, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(dados)
    print(f"Dataset salvo como '{ficheiro_saida}' com {len(dados)} exemplos.")


#6. Considerações Finais
#Este projeto mostra como diferentes técnicas de IA podem ser aplicadas a jogos simples para criar agentes com diferentes níveis de inteligência.
#Próximos passos possíveis:
#Otimização da profundidade da árvore ID3
#Discretização automática para outros tipos de dados
#Visualização dos resultados e partidas simuladas entre bots

#7. Conclusão
#Neste trabalho conseguimos aplicar dois conceitos centrais da Inteligência Artificial: algoritmos de busca adversarial (MCTS) e aprendizagem supervisionada (ID3). O algoritmo MCTS demonstrou alta eficácia na escolha de jogadas através de simulações, sendo também útil como gerador de dados para treinar o ID3. Já a árvore de decisão mostrou-se uma solução rápida e relativamente eficiente, ideal para bots de desempenho médio. Além disso, estruturamos toda a lógica do jogo de forma modular e clara, o que facilitou testes e integração. Este projeto serviu como uma excelente oportunidade para compreender como estratégias diferentes podem ser aplicadas a jogos e tomadas de decisão.

