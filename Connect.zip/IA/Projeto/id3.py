import numpy as np
import csv
import math
import random
from Connect4 import create_board, jogada, board_full, won
from main import mcts_bot

bot = lambda jogador, board, c: mcts_bot(jogador, board, 100, c)

def gerar_data(n_jogos=500, ficheiro_saida="dataset.csv"):
    dados = []
    for _ in range(n_jogos):
        board = create_board()
        jogador = 1
        while not board_full(board) and not won(board, jogador) and not won(board, -jogador):
            estado = board.flatten().astype(int)
            jogada_feita = bot(jogador, board, math.sqrt(2))
            dados.append(np.append(estado, jogada_feita))
            board = jogada(board, jogador, jogada_feita)
            jogador *= -1
    with open(ficheiro_saida, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerows(dados)
    #print(f"Dataset salvo como '{ficheiro_saida}' com {len(dados)} exemplos.")

class NoID3:
    def __init__(self, atributo=None, filhos=None, classe=None):
        self.atributo = atributo
        self.filhos = filhos if filhos is not None else {}
        self.classe = classe

def entropia(exemplos):
    total = len(exemplos)
    if total == 0:
        return 0
    contagens = {}
    for exemplo in exemplos:
        classe = exemplo[-1]
        contagens[classe] = contagens.get(classe, 0) + 1
    ent = 0
    for count in contagens.values():
        p = count / total
        ent -= p * math.log2(p)
    return ent

def dividir(exemplos, atributo):
    divisao = {}
    for exemplo in exemplos:
        valor = exemplo[atributo]
        if valor not in divisao:
            divisao[valor] = []
        divisao[valor].append(exemplo)
    return divisao

def ganho_informacao(exemplos, atributo):
    entropia_inicial = entropia(exemplos)
    divisao = dividir(exemplos, atributo)
    total = len(exemplos)
    entropia_depois = sum((len(subconj)/total) * entropia(subconj) for subconj in divisao.values())
    return entropia_inicial - entropia_depois

def id3(exemplos, atributos):
    classes = [ex[-1] for ex in exemplos]
    if all(c == classes[0] for c in classes):
        return NoID3(classe=classes[0])
    if not atributos:
        classe_majoritaria = max(set(classes), key=classes.count)
        return NoID3(classe=classe_majoritaria)

    melhor = max(atributos, key=lambda a: ganho_informacao(exemplos, a))
    raiz = NoID3(atributo=melhor)
    divisao = dividir(exemplos, melhor)
    for valor, subconj in divisao.items():
        if not subconj:
            classe_majoritaria = max(set(classes), key=classes.count)
            raiz.filhos[valor] = NoID3(classe=classe_majoritaria)
        else:
            novos_atributos = [a for a in atributos if a != melhor]
            raiz.filhos[valor] = id3(subconj, novos_atributos)
    return raiz

def classificar(exemplo, arvore):
    while arvore.classe is None:
        valor = exemplo[arvore.atributo]
        if valor in arvore.filhos:
            arvore = arvore.filhos[valor]
        else:
            return None
    return arvore.classe

def carregar_dataset(ficheiro):
    with open(ficheiro, "r") as f:
        linhas = list(csv.reader(f))
        dados = [list(map(int, linha)) for linha in linhas]
    return dados

def avaliar_id3(dados, proporcao_treino=0.8):
    random.shuffle(dados)
    n = int(len(dados) * proporcao_treino)
    treino = dados[:n]
    teste = dados[n:]
    atributos = list(range(len(dados[0]) - 1))
    arvore = id3(treino, atributos)
    corretos = 0
    for ex in teste:
        pred = classificar(ex, arvore)
        if pred == ex[-1]:
            corretos += 1
    acc = corretos / len(teste)
    print(f"Acurácia: {acc:.2%}")
    return arvore

if __name__ == "__main__":
    gerar_data(n_jogos=500, ficheiro_saida="dataset.csv")
