import numpy as np
import copy
import math
import time


def create_board():
    #cria o tabuleiro
    board = np.zeros((6,7))
    return board

def jogada(board, player, col):
    tab = copy.deepcopy(board)
    jogadas_possiveis = jogada_possivel(tab)
    if (jogadas_possiveis[col]==0):
        raise Exception("Jogada impossível!")
    row = sum(tab[:,col] == 0) - 1
    tab[row, col] = player
    return tab


def jogada_possivel(board):
    jogadas_possiveis = [0] * 7
    for col in range(7):
        if sum(board[:,col] == 0) > 0:
            jogadas_possiveis[col] = 1
    return jogadas_possiveis


def board_full(board):
    #verifica se o tabuleiro está cheio
    return sum(board.flatten() == 0) == 0
    
def won(board, player):
    #retorna True se o player ganhar
    #verificar na vertical
    for col in range(7):
        for row in range(3):
            if board[row, col] == board[row+1, col] == board[row+2, col] == board[row+3, col] == player:
                return True
            
    #verificar na horizontal
    for row in range(6):
        for col in range(4):
            if board[row, col] == board[row, col+1] == board[row, col+2] == board[row, col+3] == player:
                return True
            
    #verificar na diagonal de cima da esquerda para baixo da direita
    for row in range(3):
        for col in range(4):
            if board[row, col] == board[row+1, col+1] == board[row+2, col+2] == board[row+3, col+3] == player:
                return True
    #verificar na diagonal de baixo da esquerda para cima da direita
    for row in range(3, 6):
        for col in range(4):
            if board[row, col] == board[row-1, col+1] == board[row-2, col+2] == board[row-3, col+3] == player:
                return True
    
    return False
    
    
def print_board(board):
    #imprime o tabuleiro jogado
    jogo = ""
    for row in range(6):
        for col in range(7):
            if board[row][col] == 0:
                jogo = jogo + "- "
            elif board[row][col] == 1:
                jogo = jogo + "X "
            else:
                jogo = jogo + "O "
        jogo = jogo + '\n'
    jogo = jogo + '1 2 3 4 5 6 7\n'
    print(jogo)



class MCTSNode():
    #classe que define o método de Monte Carlo Tree Search
    
    def __init__(self, state, player, parent=None, parent_action=None):
        #gerador inicial
        
        self.state = state                                            #Estado do board
        self.parent = parent                                          #Nó anterior
        self.parent_action = parent_action                            #coluna do nó anterior
        self.children = []                                            #número de nós filhos
        self._number_of_visits = 0                                    #número de vezes que o nó foi visitado
        self.q =0                                                     #valor de q do nodo
        self._untried_actions = self.untried_actions()                #jogadas possíveis a partir desse nó
        self.player = player                                          #jogador atual
        return
    
    
    def untried_actions(self):
        #devolve um array de jogadas possíveis
        
        possible = jogada_possivel(self.state)
        return [col for col in range(7) if possible[col] == 1]
    
    
    def n(self):
        #devolve o número de visitas a esse nó
        
        return self._number_of_visits
    
    
    def expand(self):
        #função que expande o nó para ver os filhos possíveis
        
        action = self._untried_actions.pop()
        next_state = self.move(action,self.player,self.state)
        child_node = MCTSNode(next_state,-self.player, parent=self, parent_action=action)
        self.children.append(child_node)
        return child_node 
    
    
    def is_terminal_node(self):
        #função que verifica se o nó é final
        
        return won(self.state,self.player) or won(self.state, -self.player) or board_full(self.state)
    
    
    def rollout(self):
        #função para saber o resultado da simulação selecionando aleatoriamente a função
        
        current_state = np.copy(self.state)
        current_player = self.player
        while not self.is_terminal_node():
            possible = jogada_possivel(current_state)
            available = [col for col in range(7) if possible[col] == 1]
            if not available:
                break
            action = np.random.choice(available)
            current_state = jogada(current_state, current_player, action)
            current_player *= -1
        return self.game_result(current_state)
    
   
    def backpropagate(self, result):
        #função para fazer backpropagation do resultado da simulação até ao nodo principal
        
        current = self
        while current is not None:
            current._number_of_visits += 1
            if result == current.player:
                current.q += 1
            elif result == 0:
                current.q += 0.5
            current = current.parent
        return

    
    def is_fully_expanded(self):
        #função para verificar se o nodo foi extendido totalmente
        
        return len(self._untried_actions) == 0
    
    
    def best_child(self, c):
        #função para avaliar qual é o melhor nodo filho a escolher
        
        best_score = 0
        best_child = None
        for child in self.children:
            if child.n() == 0:
                return child
            else:
                exploitation = child.q / child.n()
                exploration = c * math.sqrt(math.log(child.parent.n()) / child.n())
                score = exploitation + exploration
            if score > best_score:
                best_score = score
                best_child = child
        if best_child is None:
            return self
        return best_child
    
    
    def _tree_policy(self):
        #função que define como elaborar a árvore de expansão
        
        current_node = self
        while not current_node.is_terminal_node():
            if not current_node.is_fully_expanded():
                return current_node.expand()
            else:
                current_node = current_node.best_child(c=math.sqrt(2))
        return current_node
    
    
    def best_action(self,time_limit, c):
        #função que decide qual é a melhor acção a tomar
        
        start_time = time.process_time()
        nodes=0
        while time.process_time() - start_time < time_limit:
            v = self._tree_policy()
            reward = v.rollout()
            v.backpropagate(reward)
        return self.most_visited_child()

    
    def most_visited_child(self):
        #função que identifica o nodo mais visitado
        
        max_visits = -1
        best_child = None
        for child in self.children:
            visits = child.n()
            if visits > max_visits:
                max_visits = visits
                best_child = child
        return best_child


    def game_result(self,board):
        #define o resultado
        
        if won(board, 1):
            return 1
        elif won(board, -1):
            return -1
        else:
            return 0

        
    def move(self, action, jogador, board):
        #efetua a jogada
        
        return jogada(board, jogador, action)

    
def bot(player, board, constant):
    #função para dar criar o bot e a sua jogada
    
    tab = copy.deepcopy(board)
    root = MCTSNode(tab, player)
    best = root.best_action(4, constant)
    played = best.parent_action
    return played
    
    

    
    
    
board = create_board()
print("Escolhe o tipo de jogo: 1 - PvP; 2 - PvBot; 3 - BotvBot")
game = int(input())
gameover = False
jogador = 1
print_board(board)
turn = 1

if game == 1:
    while gameover == False:
        if jogador == 1:
            turn = 1
        else:
            turn = 2
        print("Faça a sua jogada (1-7), jogador ", turn)
        played = int(input()) - 1
        
        if (played<0 or played>6):
            raise Exception("Jogada impossível!")
         
        board = jogada(board, jogador, played)
        print_board(board)
        print("O jogador ", turn, " jogou ", played)
        
        if won(board, jogador):
            print("O jogador ", turn, " ganhou!")
            break
            
        elif board_full(board):
            print("Os dois jogadores empataram!")
            break
           
        jogador *= -1
        
elif game == 2:
    while gameover == False:
        
        print("Faça a sua jogada (1-7), jogador 1")
        played = int(input()) - 1
        
        if (played<0 or played>6):
            raise Exception("Jogada impossível!")
         
        board = jogada(board, 1, played)
        print_board(board)
        print("O jogador ", turn, " jogou ", played)
        
        if won(board, 1):
            print("O jogador ganhou!")
            break
            
        elif board_full(board):
            print("Empataram!")
            break
            

        start_time = time.process_time()
        played_bot = bot(-1, board, math.sqrt(2))
        board = jogada(board, -11, played_bot)
        print_board(board)
        print("O computador jogou", played_bot+1)
        
        
        if won(board, -1):
            print("O jogador perdeu!")
            break
            
        elif board_full(board):
            print("Empataram!")
            break
            
        
elif game == 3:
    while gameover == False:
        
        start_time = time.process_time()
        played_bot1 = bot(1, board, math.sqrt(2))
        board = jogada(board, 1, played_bot1)
        print_board(board)
        print("O Bot 1 jogou", played_bot1 + 1)
        
        
        if won(board, 1):
            print("O Bot 1 ganhou!")
            break
            
        elif board_full(board):
            print("Empataram!")
            break


        start_time = time.process_time()
        played_bot2 = bot(-1, board, math.sqrt(2))
        board = jogada(board, -1, played_bot2)
        print_board(board)
        print("O Bot 2 jogou", played_bot2 + 1)
        
        
        if won(board, -1):
            print("O Bot 2 ganhou!")
            break
            
        elif board_full(board):
            print("Empataram!")
            break
        
            
        
        
    

