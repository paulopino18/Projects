"""
tree_vis.py
-----------
Funções de visualização da árvore de decisão ID3.

Oferece duas formas de visualização:
  1. print_tree()  → representação em texto no terminal (útil para debug)
  2. plot_tree()   → gráfico matplotlib com caixas e setas
  3. export_rules() → lista de regras if-then em texto legível

Requisitos: matplotlib
"""

import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
import numpy as np
from collections import deque


# ══════════════════════════════════════════════
#  1. Representação textual
# ══════════════════════════════════════════════

def print_tree(node, feature_names=None, indent: str = "", is_last: bool = True):
    """
    Imprime a árvore em formato de texto hierárquico.

    Args:
        node:          DecisionNode raiz
        feature_names: lista de nomes de features (opcional)
        indent:        prefixo de indentação (uso interno recursivo)
        is_last:       se este nó é o último filho do pai (uso interno)

    Exemplo de output:
        └── [petal_length <= 2.4500]
            ├── (<= 2.4500)
            │   └── [LEAF] Iris-setosa  (50 amostras)
            └── (> 2.4500)
                └── [petal_width <= 1.7500]
                    ...
    """
    connector = "└── " if is_last else "├── "
    child_prefix = "    " if is_last else "│   "

    if node.is_leaf():
        dist_str = ""
        if node.class_distribution:
            parts = [f"{k}:{v}" for k, v in sorted(node.class_distribution.items(), key=lambda x: -x[1])]
            dist_str = "  {" + ", ".join(parts) + "}"
        print(f"{indent}{connector}[FOLHA] → {node.label}  (n={node.samples}){dist_str}")
        return

    # Nó interno
    if node.is_continuous and node.threshold is not None:
        feat_str = f"{node.feature_name} ≤ {node.threshold:.4f}?"
    else:
        feat_str = f"{node.feature_name}?"
    print(f"{indent}{connector}[{feat_str}]  (n={node.samples}, profundidade={node.depth})")

    branches = list(node.branches.items())
    for i, (val, child) in enumerate(branches):
        last_child   = (i == len(branches) - 1)
        val_connector = "└── " if last_child else "├── "
        val_prefix    = "    " if last_child else "│   "
        print(f"{indent}{child_prefix}{val_connector}({val})")
        print_tree(child, feature_names, indent + child_prefix + val_prefix, True)


# ══════════════════════════════════════════════
#  2. Visualização Matplotlib
# ══════════════════════════════════════════════

# Paleta de cores para classes
_CLASS_PALETTE = [
    "#AED6F1", "#A9DFBF", "#F9E79F", "#F1948A",
    "#D2B4DE", "#FDEBD0", "#A3E4D7", "#FAD7A0",
]


def plot_tree(
    root,
    feature_names  = None,
    class_colors   = None,
    figsize        = (22, 14),
    title          : str  = "Árvore de Decisão ID3",
    max_depth_plot : int  = None,
    save_path      : str  = None,
):
    """
    Gera um gráfico da árvore de decisão com matplotlib.

    Args:
        root:           DecisionNode raiz da árvore
        feature_names:  lista de nomes das features
        class_colors:   dict {label → cor HTML}. Se None, usa paleta automática.
        figsize:        tamanho da figura (largura, altura)
        title:          título do gráfico
        max_depth_plot: limita a profundidade visualizada (None = toda a árvore)
        save_path:      se definido, guarda a figura neste caminho (ex: "tree.png")

    Returns:
        matplotlib.figure.Figure
    """
    # ── Recolhe todos os labels de folha para a paleta ──
    all_labels = _collect_labels(root)
    if class_colors is None:
        class_colors = {
            label: _CLASS_PALETTE[i % len(_CLASS_PALETTE)]
            for i, label in enumerate(sorted(all_labels))
        }

    # ── Calcula posições dos nós ──
    positions = {}
    _assign_positions(root, positions, cx=0.5, cy=0.95,
                      x_span=1.0, depth=0, max_depth=max_depth_plot)

    # ── Desenha ──
    fig, ax = plt.subplots(figsize=figsize)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    fig.patch.set_facecolor("#F8F9FA")
    ax.set_facecolor("#F8F9FA")

    ax.set_title(title, fontsize=15, fontweight="bold", pad=16,
                 color="#2C3E50")

    _draw_edges_recursive(ax, root, positions, max_depth_plot)
    _draw_nodes_recursive(ax, root, positions, class_colors, max_depth_plot)

    # ── Legenda de classes ──
    patches = [
        mpatches.Patch(facecolor=c, edgecolor="gray", label=str(lbl))
        for lbl, c in class_colors.items()
    ]
    ax.legend(handles=patches, title="Classes", loc="upper right",
              fontsize=9, title_fontsize=10, framealpha=0.85)

    # ── Estatísticas no canto ──
    stats = _tree_stats(root)
    stats_text = (
        f"Profundidade: {stats['depth']}\n"
        f"Nós internos: {stats['internal']}\n"
        f"Folhas: {stats['leaves']}"
    )
    ax.text(0.01, 0.01, stats_text, transform=ax.transAxes,
            fontsize=9, verticalalignment="bottom",
            bbox=dict(boxstyle="round,pad=0.4", facecolor="white",
                      edgecolor="#BDC3C7", alpha=0.9))

    plt.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Figura guardada em: {save_path}")

    return fig


# ── Posicionamento dos nós ────────────────────

def _assign_positions(node, positions, cx, cy, x_span, depth, max_depth):
    """
    Atribui coordenadas (x, y) a cada nó usando BFS iterativo.
    Evita recursão profunda para árvores grandes.
    """
    # BFS: queue de (node, cx, cy, x_span, depth)
    queue = deque([(node, cx, cy, x_span, depth)])

    while queue:
        cur_node, x, y, span, d = queue.popleft()
        positions[id(cur_node)] = (x, y)

        if cur_node.is_leaf():
            continue
        if max_depth is not None and d >= max_depth:
            continue

        children = list(cur_node.branches.items())
        n = len(children)
        if n == 0:
            continue

        child_span = span / n
        child_y    = y - 0.13

        for i, (val, child) in enumerate(children):
            child_x = x - span / 2 + child_span * (i + 0.5)
            queue.append((child, child_x, child_y, child_span * 0.92, d + 1))


# ── Desenho de arestas ────────────────────────

def _draw_edges_recursive(ax, node, positions, max_depth):
    """Desenha linhas entre nós pai e filho."""
    queue = deque([node])
    while queue:
        cur = queue.popleft()
        if cur.is_leaf() or not cur.branches:
            continue
        if max_depth is not None and cur.depth >= max_depth:
            continue

        px, py = positions[id(cur)]

        for val, child in cur.branches.items():
            if id(child) not in positions:
                continue
            cx, cy = positions[id(child)]

            ax.plot([px, cx], [py, cy], "-", color="#95A5A6",
                    linewidth=1.2, zorder=1, alpha=0.7)

            # Label da aresta
            mid_x = (px + cx) / 2
            mid_y = (py + cy) / 2
            ax.text(mid_x, mid_y, str(val), fontsize=6.5, ha="center", va="center",
                    color="#2C3E50", zorder=3,
                    bbox=dict(boxstyle="round,pad=0.15", facecolor="#FDFEFE",
                              edgecolor="#BDC3C7", alpha=0.85, linewidth=0.7))

            queue.append(child)


# ── Desenho de nós ────────────────────────────

def _draw_nodes_recursive(ax, node, positions, class_colors, max_depth):
    """Desenha caixas para nós internos e folhas."""
    queue = deque([node])
    while queue:
        cur = queue.popleft()
        if id(cur) not in positions:
            continue

        px, py = positions[id(cur)]

        if cur.is_leaf():
            color = class_colors.get(cur.label, "#D5D8DC")
            text  = f"Classe\n{cur.label}"
            if cur.samples:
                text += f"\n(n={cur.samples})"
            bbox_props = dict(boxstyle="round,pad=0.45", facecolor=color,
                              edgecolor="#2C3E50", linewidth=1.8, alpha=0.95)
            ax.text(px, py, text, fontsize=7.5, ha="center", va="center",
                    bbox=bbox_props, zorder=4, fontweight="bold", color="#1A252F")
        else:
            if max_depth is not None and cur.depth >= max_depth:
                # Nó truncado
                ax.text(px, py, "...", fontsize=9, ha="center", va="center",
                        bbox=dict(boxstyle="round,pad=0.3", facecolor="#ECF0F1",
                                  edgecolor="#95A5A6"), zorder=4)
                continue

            if cur.is_continuous and cur.threshold is not None:
                label = f"{cur.feature_name}\n≤ {cur.threshold:.3f}?"
            else:
                label = f"{cur.feature_name}?"

            if cur.samples:
                label += f"\n(n={cur.samples})"

            bbox_props = dict(boxstyle="round,pad=0.45", facecolor="#D6EAF8",
                              edgecolor="#1A5276", linewidth=1.8, alpha=0.95)
            ax.text(px, py, label, fontsize=7.5, ha="center", va="center",
                    bbox=bbox_props, zorder=4, color="#1A252F")

            for child in cur.branches.values():
                queue.append(child)


# ══════════════════════════════════════════════
#  3. Export de regras if-then
# ══════════════════════════════════════════════

def export_rules(root, feature_names=None) -> list:
    """
    Extrai todas as regras if-then da árvore.

    Returns:
        Lista de strings, uma por folha. Exemplo:
            "IF petal_length <= 2.4500 AND petal_width <= 1.0000 THEN Iris-setosa"
    """
    rules = []
    _extract_rules(root, conditions=[], rules=rules)
    return rules


def _extract_rules(node, conditions, rules):
    """Recursão para extração de regras."""
    if node.is_leaf():
        if conditions:
            antecedent = " AND ".join(conditions)
            rules.append(f"IF {antecedent} THEN {node.label}")
        else:
            rules.append(f"THEN {node.label}")
        return

    for val, child in node.branches.items():
        if node.is_continuous and node.threshold is not None:
            cond = f"{node.feature_name} {val}"
        else:
            cond = f"{node.feature_name} = {val}"

        _extract_rules(child, conditions + [cond], rules)


def print_rules(root, feature_names=None):
    """Imprime as regras da árvore no formato if-then."""
    rules = export_rules(root, feature_names)
    print(f"\n{'='*60}")
    print(f"  {len(rules)} regras extraídas da árvore")
    print(f"{'='*60}")
    for i, rule in enumerate(rules, 1):
        print(f"  {i:3d}. {rule}")
    print(f"{'='*60}\n")


# ══════════════════════════════════════════════
#  Auxiliares
# ══════════════════════════════════════════════

def _collect_labels(node) -> set:
    """Recolhe todos os labels de folha da árvore."""
    if node.is_leaf():
        return {node.label}
    labels = set()
    for child in node.branches.values():
        labels |= _collect_labels(child)
    return labels


def _tree_stats(node) -> dict:
    """Devolve estatísticas simples da árvore."""
    stats = {"depth": 0, "internal": 0, "leaves": 0}
    queue = deque([(node, 0)])
    while queue:
        cur, d = queue.popleft()
        stats["depth"] = max(stats["depth"], d)
        if cur.is_leaf():
            stats["leaves"] += 1
        else:
            stats["internal"] += 1
            for child in cur.branches.values():
                queue.append((child, d + 1))
    return stats
