"""
decision_tree/
--------------
Pacote de aprendizagem automática com árvores de decisão ID3.

Módulos:
  entropy     — cálculo de entropia de Shannon e ganho de informação
  discretize  — discretização de atributos contínuos (para o dataset Iris)
  id3         — algoritmo ID3 completo (categórico + contínuo)
  tree_vis    — visualização textual e gráfica da árvore

Uso típico:
    from decision_tree.id3 import ID3
    from decision_tree.discretize import Discretizer
    from decision_tree.tree_vis import plot_tree, print_tree, print_rules
"""

from .id3 import ID3, DecisionNode
from .entropy import entropy, information_gain, best_threshold
from .discretize import Discretizer
from .tree_vis import plot_tree, print_tree, print_rules, export_rules

__all__ = [
    "ID3",
    "DecisionNode",
    "entropy",
    "information_gain",
    "best_threshold",
    "Discretizer",
    "plot_tree",
    "print_tree",
    "print_rules",
    "export_rules",
]
