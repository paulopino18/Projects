import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicReference;

public class ChatClient {

    private enum State { INIT, OUTSIDE, INSIDE }
    private enum Pending { NONE, NICK, JOIN, LEAVE, BYE, PRIV }

    private JFrame frame;
    private JTextField input;
    private JTextArea chat;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    private volatile State state = State.INIT;
    private final AtomicReference<Pending> pending = new AtomicReference<>(Pending.NONE);
    private volatile boolean running = true;

    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.err.println("Usage: java ChatClient <host> <port>");
            return;
        }
        ChatClient c = new ChatClient();
        c.ui();
        c.connect(args[0], Integer.parseInt(args[1]));
        c.reader();
    }

    private void ui() {
        frame = new JFrame("ChatClient");
        input = new JTextField();
        chat = new JTextArea();
        chat.setEditable(false);

        frame.setLayout(new BorderLayout());
        frame.add(new JScrollPane(chat), BorderLayout.CENTER);
        frame.add(input, BorderLayout.SOUTH);
        frame.setSize(700, 450);
        frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        frame.setVisible(true);

        input.addActionListener(e -> {
            String t = input.getText();
            if (t == null) return;
            t = t.trim();
            if (!t.isEmpty()) send(t);
            input.setText("");
        });

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                input.setEditable(false);
                send("/bye");
            }
        });
    }

    private void connect(String host, int port) throws IOException {
        socket = new Socket(host, port);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
    }

    private void reader() {
        new Thread(() -> {
            try {
                String line;
                while (running && (line = in.readLine()) != null) {
                    String l = line;
                    SwingUtilities.invokeLater(() -> handle(l));
                }
            } catch (IOException ignored) {
            } finally {
                SwingUtilities.invokeLater(this::shutdown);
            }
        }).start();
    }

    private boolean isSupportedCommand(String t) {
        if (!t.startsWith("/")) return false;
        if (t.equals("/leave")) return true;
        if (t.equals("/bye")) return true;
        if (t.startsWith("/nick ")) return true;
        if (t.startsWith("/join ")) return true;
        if (t.startsWith("/priv ")) return true;
        return false;
    }

    private void send(String t) {
        if (out == null) return;

        if (t.startsWith("/")) {
            if (t.startsWith("/nick ")) pending.set(Pending.NICK);
            else if (t.startsWith("/join ")) pending.set(Pending.JOIN);
            else if (t.equals("/leave")) pending.set(Pending.LEAVE);
            else if (t.equals("/bye")) pending.set(Pending.BYE);
            else if (t.startsWith("/priv ")) pending.set(Pending.PRIV);
            else pending.set(Pending.NONE);

            if (state == State.INSIDE && !isSupportedCommand(t)) {
                t = "/" + t;
            }
        } else {
            pending.set(Pending.NONE);
        }

        out.println(t);
    }

    private void handle(String l) {
        if (l.equals("OK")) {
            Pending p = pending.getAndSet(Pending.NONE);
            if (p == Pending.NICK && state == State.INIT) state = State.OUTSIDE;
            if (p == Pending.JOIN) state = State.INSIDE;
            if (p == Pending.LEAVE) state = State.OUTSIDE;
            return;
        }

        if (l.equals("ERROR")) {
            pending.set(Pending.NONE);
            return;
        }

        if (l.equals("BYE")) {
            pending.set(Pending.NONE);
            shutdown();
            return;
        }

        if (l.startsWith("MESSAGE ")) {
            String[] p = l.split(" ", 3);
            if (p.length >= 3) append(p[1] + ": " + p[2]);
            return;
        }

        if (l.startsWith("PRIVATE ")) {
            String[] p = l.split(" ", 3);
            if (p.length >= 3) append("(priv) " + p[1] + ": " + p[2]);
            return;
        }

        if (l.startsWith("NEWNICK ")) {
            String[] p = l.split(" ", 3);
            if (p.length >= 3) append(p[1] + " mudou de nome para " + p[2]);
            return;
        }

        if (l.startsWith("JOINED ")) {
            append(l.substring(7) + " entrou");
            return;
        }

        if (l.startsWith("LEFT ")) {
            append(l.substring(5) + " saiu");
        }
    }

    private void append(String s) {
        chat.append(s + "\n");
    }

    private void shutdown() {
        if (!running) return;
        running = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        try { if (in != null) in.close(); } catch (Exception ignored) {}
        if (out != null) out.close();
        frame.dispose();
    }
}
