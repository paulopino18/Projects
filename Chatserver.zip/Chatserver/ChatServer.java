import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ChatServer {

    private static final Charset CS = StandardCharsets.UTF_8;

    private enum State { INIT, OUTSIDE, INSIDE }

    private static final class Client {
        final SocketChannel ch;
        final SelectionKey key;
        final ByteBuffer readBuf = ByteBuffer.allocate(8192);
        final StringBuilder in = new StringBuilder();
        final ArrayDeque<ByteBuffer> outQ = new ArrayDeque<>();
        boolean closeAfterFlush = false;
        State state = State.INIT;
        String nick = null;
        String room = null;

        Client(SocketChannel ch, SelectionKey key) {
            this.ch = ch;
            this.key = key;
        }
    }

    private final Selector selector;
    private final ServerSocketChannel server;

    private final Map<String, Client> byNick = new HashMap<>();
    private final Map<String, LinkedHashSet<Client>> rooms = new HashMap<>();
    private final Map<SocketChannel, Client> clients = new HashMap<>();

    private ChatServer(int port) throws IOException {
        selector = Selector.open();
        server = ServerSocketChannel.open();
        server.configureBlocking(false);
        server.bind(new InetSocketAddress(port));
        server.register(selector, SelectionKey.OP_ACCEPT);
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Usage: java ChatServer <port>");
            return;
        }
        new ChatServer(Integer.parseInt(args[0])).loop();
    }

    private void loop() throws IOException {
        while (true) {
            selector.select();
            Iterator<SelectionKey> it = selector.selectedKeys().iterator();
            while (it.hasNext()) {
                SelectionKey key = it.next();
                it.remove();
                if (!key.isValid()) continue;
                try {
                    if (key.isAcceptable()) accept();
                    if (key.isReadable()) read(key);
                    if (key.isWritable()) write(key);
                } catch (IOException e) {
                    drop(key);
                }
            }
        }
    }

    private void accept() throws IOException {
        SocketChannel ch = server.accept();
        if (ch == null) return;
        ch.configureBlocking(false);
        SelectionKey key = ch.register(selector, SelectionKey.OP_READ);
        Client c = new Client(ch, key);
        key.attach(c);
        clients.put(ch, c);
    }

    private void read(SelectionKey key) throws IOException {
        Client c = (Client) key.attachment();
        int n = c.ch.read(c.readBuf);
        if (n == -1) {
            clientClosed(c);
            return;
        }
        if (n == 0) return;

        c.readBuf.flip();
        CharBuffer cb = CS.decode(c.readBuf);
        c.readBuf.clear();
        c.in.append(cb);

        while (true) {
            int i = c.in.indexOf("\n");
            if (i < 0) break;
            String line = c.in.substring(0, i);
            if (line.endsWith("\r")) line = line.substring(0, line.length() - 1);
            c.in.delete(0, i + 1);
            handleLine(c, line);
        }
    }

    private void write(SelectionKey key) throws IOException {
        Client c = (Client) key.attachment();

        while (!c.outQ.isEmpty()) {
            ByteBuffer b = c.outQ.peekFirst();
            c.ch.write(b);
            if (b.hasRemaining()) {
                key.interestOps(key.interestOps() | SelectionKey.OP_WRITE);
                return;
            }
            c.outQ.removeFirst();
        }

        key.interestOps(key.interestOps() & ~SelectionKey.OP_WRITE);

        if (c.closeAfterFlush) {
            closeNow(c);
        }
    }

    private void send(Client c, String s) {
        c.outQ.add(ByteBuffer.wrap((s + "\n").getBytes(CS)));
        c.key.interestOps(c.key.interestOps() | SelectionKey.OP_WRITE);
        selector.wakeup();
    }

    private void handleLine(Client c, String line) {
        if (c.state == State.INSIDE && line.startsWith("//")) {
            message(c, line.substring(1));
            return;
        }

        if (line.startsWith("/")) {
            command(c, line);
            return;
        }

        if (c.state == State.INSIDE) message(c, line);
        else send(c, "ERROR");
    }

    private void command(Client c, String line) {
        String[] p = line.split(" ", 2);
        String cmd = p[0];
        String rest = p.length > 1 ? p[1] : null;

        switch (cmd) {
            case "/nick": nick(c, rest); break;
            case "/join": join(c, rest); break;
            case "/leave": leave(c); break;
            case "/bye": bye(c); break;
            case "/priv": priv(c, rest); break;
            default: send(c, "ERROR");
        }
    }

    private boolean validToken(String s) {
        return s != null && !s.trim().isEmpty() && !s.contains(" ");
    }

    private void nick(Client c, String name) {
        if (!validToken(name)) {
            send(c, "ERROR");
            return;
        }

        Client used = byNick.get(name);
        if (used != null && used != c) {
            send(c, "ERROR");
            return;
        }

        if (c.state == State.INIT) {
            c.nick = name;
            byNick.put(name, c);
            c.state = State.OUTSIDE;
            send(c, "OK");
            return;
        }

        String old = c.nick;

        if (old != null && old.equals(name)) {
            send(c, "OK");
            return;
        }

        if (old != null) byNick.remove(old);
        c.nick = name;
        byNick.put(name, c);
        send(c, "OK");

        if (c.state == State.INSIDE && c.room != null && old != null) {
            broadcastExcept(c.room, c, "NEWNICK " + old + " " + name);
        }
    }

    private void join(Client c, String room) {
        if (!validToken(room) || c.state == State.INIT) {
            send(c, "ERROR");
            return;
        }

        String oldRoom = c.room;
        boolean wasInside = (c.state == State.INSIDE && oldRoom != null);

        send(c, "OK");

        if (wasInside) {
            removeFromRoom(c, oldRoom);
            c.room = null;
            broadcastToRoom(oldRoom, "LEFT " + c.nick);
        }

        rooms.computeIfAbsent(room, r -> new LinkedHashSet<>()).add(c);
        c.room = room;
        c.state = State.INSIDE;

        broadcastExcept(room, c, "JOINED " + c.nick);
    }

    private void leave(Client c) {
        if (c.state != State.INSIDE || c.room == null) {
            send(c, "ERROR");
            return;
        }

        String oldRoom = c.room;

        send(c, "OK");

        removeFromRoom(c, oldRoom);
        c.room = null;
        c.state = State.OUTSIDE;

        broadcastToRoom(oldRoom, "LEFT " + c.nick);
    }

    private void bye(Client c) {
        send(c, "BYE");

        if (c.state == State.INSIDE && c.room != null && c.nick != null) {
            String oldRoom = c.room;
            removeFromRoom(c, oldRoom);
            c.room = null;
            broadcastToRoom(oldRoom, "LEFT " + c.nick);
        }

        if (c.nick != null) {
            byNick.remove(c.nick);
            c.nick = null;
        }

        c.state = State.INIT;
        c.closeAfterFlush = true;
        c.key.interestOps(c.key.interestOps() | SelectionKey.OP_WRITE);
        selector.wakeup();
    }

    private void priv(Client c, String rest) {
        if (c.state == State.INIT || c.nick == null || rest == null) {
            send(c, "ERROR");
            return;
        }

        String[] p = rest.split(" ", 2);
        if (p.length < 2 || !validToken(p[0])) {
            send(c, "ERROR");
            return;
        }

        Client t = byNick.get(p[0]);
        if (t == null) {
            send(c, "ERROR");
            return;
        }

        send(c, "OK");
        send(t, "PRIVATE " + c.nick + " " + p[1]);
    }

    private void message(Client c, String msg) {
        if (c.state != State.INSIDE || c.room == null || c.nick == null) {
            send(c, "ERROR");
            return;
        }
        broadcastAll(c.room, "MESSAGE " + c.nick + " " + msg);
    }

    private void broadcastAll(String room, String msg) {
        LinkedHashSet<Client> set = rooms.get(room);
        if (set == null) return;
        for (Client x : set) send(x, msg);
    }

    private void broadcastToRoom(String room, String msg) {
        LinkedHashSet<Client> set = rooms.get(room);
        if (set == null) return;
        for (Client x : set) send(x, msg);
    }

    private void broadcastExcept(String room, Client except, String msg) {
        LinkedHashSet<Client> set = rooms.get(room);
        if (set == null) return;
        for (Client x : set) if (x != except) send(x, msg);
    }

    private void removeFromRoom(Client c, String room) {
        LinkedHashSet<Client> set = rooms.get(room);
        if (set == null) return;
        set.remove(c);
        if (set.isEmpty()) rooms.remove(room);
    }

    private void clientClosed(Client c) {
        if (c.state == State.INSIDE && c.room != null && c.nick != null) {
            String oldRoom = c.room;
            removeFromRoom(c, oldRoom);
            c.room = null;
            broadcastToRoom(oldRoom, "LEFT " + c.nick);
        }
        if (c.nick != null) byNick.remove(c.nick);
        closeNow(c);
    }

    private void drop(SelectionKey key) {
        try {
            Client c = (Client) key.attachment();
            clientClosed(c);
        } catch (Exception ignored) {}
    }

    private void closeNow(Client c) {
        try {
            if (c.room != null) {
                removeFromRoom(c, c.room);
                c.room = null;
            }
            if (c.nick != null) {
                byNick.remove(c.nick);
                c.nick = null;
            }
            clients.remove(c.ch);
            c.key.cancel();
            c.ch.close();
        } catch (IOException ignored) {}
    }
}
