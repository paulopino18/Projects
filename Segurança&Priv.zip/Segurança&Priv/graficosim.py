import pandas as pd
import matplotlib.pyplot as plt

aes = pd.read_csv("resultados/aes_results.csv")
rsa = pd.read_csv("resultados/rsa_results.csv")
sha = pd.read_csv("resultados/sha_results.csv")

# =========================
# Gráfico AES
# =========================
plt.figure()
plt.plot(aes["file_size"], aes["enc_mean_us"], marker='o', label="AES Encrypt")
plt.plot(aes["file_size"], aes["dec_mean_us"], marker='o', label="AES Decrypt")

plt.xscale("log")
plt.xlabel("File size (bytes)")
plt.ylabel("Time (µs)")
plt.title("AES Performance")
plt.legend()

plt.savefig("aes_plot.png")
plt.close()


# =========================
# Gráfico RSA
# =========================
plt.figure()
plt.plot(rsa["file_size"], rsa["enc_mean_us"], marker='o', label="RSA Encrypt")
plt.plot(rsa["file_size"], rsa["dec_mean_us"], marker='o', label="RSA Decrypt")

plt.xscale("log")
plt.xlabel("File size (bytes)")
plt.ylabel("Time (µs)")
plt.title("RSA Performance")
plt.legend()

plt.savefig("rsa_plot.png")
plt.close()


# =========================
# Gráfico SHA
# =========================
plt.figure()
plt.plot(sha["file_size"], sha["sha_mean_us"], marker='o', label="SHA-256")

plt.xscale("log")
plt.xlabel("File size (bytes)")
plt.ylabel("Time (µs)")
plt.title("SHA-256 Performance")
plt.legend()

plt.savefig("sha_plot.png")
plt.close()

print("✅ Gráficos gerados com sucesso!")