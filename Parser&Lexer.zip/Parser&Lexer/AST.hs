module AST where

data Exp
  = -- literals & variables
    Num Int
  | Bool Bool
  | Var String

    -- arithmetic
  | Add Exp Exp
  | Sub Exp Exp
  | Mult Exp Exp
  | Div Exp Exp
  | Mod Exp Exp

    -- program structure
  | Program Exp
  | Block [Exp]

    -- statements
  | Assign Exp Exp
  | If Exp Exp
  | IfElse Exp Exp Exp
  | While Exp Exp

    -- relational / boolean
  | Equal Exp Exp
  | Diff Exp Exp
  | Less Exp Exp
  | LessEq Exp Exp
  | Greater Exp Exp
  | GreaterEq Exp Exp
  | Or Exp Exp
  | And Exp Exp
  | Not Exp

    -- Ada-subset I/O
  | PutLine Exp
  | GetLine String
  deriving (Show, Eq)
