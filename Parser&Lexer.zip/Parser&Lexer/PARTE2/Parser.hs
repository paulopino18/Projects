module Parser (parser) where

import AST
import Lexer

parser :: [Token] -> Exp
parser toks =
  case parseProgram toks of
    (ast, [])    -> ast
    (_,  leftover) -> error $ "Parser: leftover tokens " ++ show leftover

type P a = [Token] -> (a, [Token])

peek :: [Token] -> Maybe Token
peek []    = Nothing
peek (t:_) = Just t

satisfy :: (Token -> Bool) -> P Token
satisfy p (t:ts) | p t       = (t, ts)
satisfy _ []                 = error "Parser: unexpected EOF"
satisfy _ ts                 = error $ "Parser: unexpected token " ++ show (take 1 ts)

expect :: Token -> P ()
expect want (t:ts)
  | t == want = ((), ts)
  | otherwise = error $ "Parser: expected " ++ show want ++ ", got " ++ show t
expect _ [] = error "Parser: unexpected EOF (expect)"

expectId :: P String
expectId (TId s : ts) = (s, ts)
expectId (t:_)        = error $ "Parser: expected identifier, got " ++ show t
expectId []           = error "Parser: unexpected EOF (identifier)"

tok :: P Token
tok = satisfy (const True)


parseProgram :: P Exp
parseProgram ts0 =
  let (_, ts1) = expect TProcedure ts0
      (_, ts2) = expect TMain ts1
      (_, ts3) = expect TIs ts2
      (_, ts4) = expect TBegin ts3
      (ss, ts5) = parseStmts ts4
      (_, ts6) = expect TEnd ts5
      (_, ts7) = expect TMain ts6
      (_, ts8) = expect TSemicolon ts7
  in (Program (Block ss), ts8)

-- stmts : { stmt }*
parseStmts :: P [Exp]
parseStmts ts =
  case peek ts of
    Just TEnd   -> ([], ts)
    Just TElse  -> ([], ts)
    Just TSemicolon -> ([], ts) -- usually not reached
    Nothing     -> ([], ts)
    _           -> let (s1, ts1) = parseStmt ts
                       (rest, ts2) = parseStmts ts1
                   in (s1:rest, ts2)

-- stmt alternatives
parseStmt :: P Exp
parseStmt ts =
  case peek ts of
    Just (TId _) -> parseAssign ts
    Just TPut_Line -> parsePutLine ts
    Just TGet_Line -> parseGetLine ts
    Just TIf       -> parseIf ts
    Just TWhile    -> parseWhile ts
    other          -> error $ "Parser: expected a statement, got " ++ show other

-- x := expr ;
parseAssign :: P Exp
parseAssign ts0 =
  let (x, ts1)   = expectId ts0
      (_, ts2)   = expect TAssignColonEq ts1
      (e, ts3)   = parseExpr ts2
      (_, ts4)   = expect TSemicolon ts3
  in (Assign (Var x) e, ts4)

-- Put_Line ( expr ) ;
parsePutLine :: P Exp
parsePutLine ts0 =
  let (_, ts1) = expect TPut_Line ts0
      (_, ts2) = expect TLParen ts1
      (e, ts3) = parseExpr ts2
      (_, ts4) = expect TRParen ts3
      (_, ts5) = expect TSemicolon ts4
  in (PutLine e, ts5)

-- Get_Line ( id ) ;
parseGetLine :: P Exp
parseGetLine ts0 =
  let (_, ts1) = expect TGet_Line ts0
      (_, ts2) = expect TLParen ts1
      (name, ts3) = expectId ts2
      (_, ts4) = expect TRParen ts3
      (_, ts5) = expect TSemicolon ts4
  in (GetLine name, ts5)

-- if bexpr then stmts [else stmts] end if ;
parseIf :: P Exp
parseIf ts0 =
  let (_, ts1)   = expect TIf ts0
      (cond, ts2)= parseBExpr ts1
      (_, ts3)   = expect TThen ts2
      (thn, ts4) = parseStmts ts3
  in case peek ts4 of
       Just TElse ->
         let (_, ts5)     = expect TElse ts4
             (els, ts6)   = parseStmts ts5
             (_, ts7)     = expect TEnd ts6
             (_, ts8)     = expect TIf ts7
             (_, ts9)     = expect TSemicolon ts8
         in (IfElse cond (Block thn) (Block els), ts9)
       _ ->
         let (_, ts7)     = expect TEnd ts4
             (_, ts8)     = expect TIf ts7
             (_, ts9)     = expect TSemicolon ts8
         in (If cond (Block thn), ts9)

-- while bexpr loop stmts end loop ;
parseWhile :: P Exp
parseWhile ts0 =
  let (_, ts1)   = expect TWhile ts0
      (cond, ts2)= parseBExpr ts1
      (_, ts3)   = expect TLoop ts2
      (body, ts4)= parseStmts ts3
      (_, ts5)   = expect TEnd ts4
      (_, ts6)   = expect TLoop ts5
      (_, ts7)   = expect TSemicolon ts6
  in (While cond (Block body), ts7)

-- ===== Expressions with precedence =====

-- bexpr -> bterm { OR bterm }*
parseBExpr :: P Exp
parseBExpr ts0 =
  let (t1, ts1) = parseBTerm ts0
  in parseBExpr' t1 ts1
  where
    parseBExpr' acc ts =
      case peek ts of
        Just TOr ->
          let (_, ts1) = expect TOr ts
              (t2, ts2) = parseBTerm ts1
          in parseBExpr' (Or acc t2) ts2
        _ -> (acc, ts)

-- bterm -> bfactor { AND bfactor }*
parseBTerm :: P Exp
parseBTerm ts0 =
  let (f1, ts1) = parseBFactor ts0
  in parseBTerm' f1 ts1
  where
    parseBTerm' acc ts =
      case peek ts of
        Just TAnd ->
          let (_, ts1) = expect TAnd ts
              (f2, ts2) = parseBFactor ts1
          in parseBTerm' (And acc f2) ts2
        _ -> (acc, ts)

-- bfactor -> NOT bfactor | rel | ( bexpr )
parseBFactor :: P Exp
parseBFactor ts =
  case peek ts of
    Just TNot ->
      let (_, ts1) = expect TNot ts
          (e, ts2) = parseBFactor ts1
      in (Not e, ts2)
    Just TLParen ->
      let (_, ts1) = expect TLParen ts
          (e, ts2) = parseBExpr ts1
          (_, ts3) = expect TRParen ts2
      in (e, ts3)
    _ -> parseRel ts


parseRel :: [Token] -> (Exp, [Token])
parseRel ts0 =
  let (e1, ts1) = parseExpr ts0
  in case peek ts1 of
       Just TEq -> bin TEq Equal e1 ts1
       Just TNeq -> bin TNeq Diff e1 ts1
       Just TLt -> bin TLt Less e1 ts1
       Just TLe -> bin TLe LessEq e1 ts1
       Just TGt -> bin TGt Greater e1 ts1
       Just TGe -> bin TGe GreaterEq e1 ts1
       _        -> (e1, ts1)
  where
    bin :: Token -> (Exp -> Exp -> Exp) -> Exp -> [Token] -> (Exp, [Token])
    bin tcon ctor e1 ts =
      let (_, ts2)  = expect tcon ts
          (e2, ts3) = parseExpr ts2
      in (ctor e1 e2, ts3)


-- expr -> term { (+|-) term }*
parseExpr :: P Exp
parseExpr ts0 =
  let (t1, ts1) = parseTerm ts0
  in go t1 ts1
  where
    go acc ts = case peek ts of
      Just TPlus  -> let (_, ts1) = expect TPlus ts
                         (t2, ts2) = parseTerm ts1
                     in go (Add acc t2) ts2
      Just TMinus -> let (_, ts1) = expect TMinus ts
                         (t2, ts2) = parseTerm ts1
                     in go (Sub acc t2) ts2
      _           -> (acc, ts)

-- term -> factor { (*|/|mod) factor }*
parseTerm :: P Exp
parseTerm ts0 =
  let (f1, ts1) = parseFactor ts0
  in go f1 ts1
  where
    go acc ts = case peek ts of
      Just TMult -> let (_, ts1) = expect TMult ts
                        (f2, ts2) = parseFactor ts1
                    in go (Mult acc f2) ts2
      Just TDiv  -> let (_, ts1) = expect TDiv ts
                        (f2, ts2) = parseFactor ts1
                    in go (Div acc f2) ts2
      Just TMod  -> let (_, ts1) = expect TMod ts
                        (f2, ts2) = parseFactor ts1
                    in go (Mod acc f2) ts2
      _          -> (acc, ts)

-- factor -> NUM | TRUE | FALSE | ID | ( expr )
parseFactor :: P Exp
parseFactor ts =
  case peek ts of
    Just (TNum n) -> let (_, ts1) = tok ts in (Num n, ts1)
    Just TTrue    -> let (_, ts1) = expect TTrue ts in (Bool True, ts1)
    Just TFalse   -> let (_, ts1) = expect TFalse ts in (Bool False, ts1)
    Just (TId s)  -> let (_, ts1) = tok ts in (Var s, ts1)
    Just TLParen  -> let (_, ts1) = expect TLParen ts
                         (e, ts2) = parseExpr ts1
                         (_, ts3) = expect TRParen ts2
                     in (e, ts3)
    other         -> error $ "Parser: expected factor, got " ++ show other
