{-# OPTIONS_GHC -fno-warn-missing-signatures #-}
module Lexer
  ( Token(..)
  , tokenize
  ) where

import Data.Char (isSpace, isDigit, isAlpha, toLower)

-- Tokens for the Ada subset
data Token
  = TProcedure | TIs | TBegin | TEnd | TMain
  | TIf | TThen | TElse
  | TWhile | TLoop
  | TPut_Line | TGet_Line
  | TTrue | TFalse
  | TAnd | TOr | TNot
  -- arithmetic operators
  | TPlus | TMinus | TMult | TDiv | TMod
  -- relational operators
  | TEq | TNeq | TLt | TLe | TGt | TGe
  -- assignment
  | TAssignColonEq               -- :=
  -- punctuation
  | TLParen | TRParen | TColon | TSemicolon
  -- literals & identifiers
  | TNum Int
  | TId String
  deriving (Eq, Show)

tokenize :: String -> [Token]
tokenize = lexAll

lexAll :: String -> [Token]
lexAll [] = []
lexAll s0 =
  let s = skipSpaceAndComments s0
  in case s of
      [] -> []
      _  -> let (tok, rest) = lexOne s
            in tok : lexAll rest

-- Skip whitespace and Ada line comments (`-- ...\n`)
skipSpaceAndComments :: String -> String
skipSpaceAndComments = go
  where
    go [] = []
    go s@(c:cs)
      | isSpace c = go cs
      | startsWith "--" s = go (dropWhile (/= '\n') s)
      | otherwise = s

-- Lex a single token
lexOne :: String -> (Token, String)
lexOne [] = error "Internal lexer error: unexpected EOF in lexOne"
lexOne s@(c:cs)
  -- Multi-character operators 
  | startsWith ":=" s = (TAssignColonEq, drop 2 s)
  | startsWith "/=" s = (TNeq,          drop 2 s)
  | startsWith "<=" s = (TLe,           drop 2 s)
  | startsWith ">=" s = (TGe,           drop 2 s)

  -- Single-char operators / punctuation
  | c == '='  = (TEq,        cs)
  | c == '<'  = (TLt,        cs)
  | c == '>'  = (TGt,        cs)
  | c == '+'  = (TPlus,      cs)
  | c == '-'  = (TMinus,     cs)
  | c == '*'  = (TMult,      cs)
  | c == '/'  = (TDiv,       cs)
  | c == '('  = (TLParen,    cs)
  | c == ')'  = (TRParen,    cs)
  | c == ':'  = (TColon,     cs)
  | c == ';'  = (TSemicolon, cs)

  -- Number literal
  | isDigit c =
      let (digits, rest) = span isDigit s
      in (TNum (read digits), rest)

  -- Identifier / keyword (letters, digits, underscores; must start with letter)
  | isAlpha c =
      let (ident, rest) = span isIdentRest s
      in (classifyIdent ident, rest)

  | otherwise =
      error $ "Lexer error: unexpected character '" ++ [c] ++ "'"

-- Identifier characters after the first: letter, digit, underscore
isIdentRest :: Char -> Bool
isIdentRest ch = isAlpha ch || isDigit ch || ch == '_'

-- Case-insensitive keyword classification 
classifyIdent :: String -> Token
classifyIdent raw =
  case lookup (normalize raw) kwTable of
    Just t  -> t
    Nothing -> TId raw
  where
    normalize = map (\ch -> if ch == '_' then '_' else toLower ch)

kwTable :: [(String, Token)]
kwTable =
  [ ("procedure", TProcedure)
  , ("is",        TIs)
  , ("begin",     TBegin)
  , ("end",       TEnd)
  , ("main",      TMain)
  , ("if",        TIf)
  , ("then",      TThen)
  , ("else",      TElse)
  , ("while",     TWhile)
  , ("loop",      TLoop)
  , ("true",      TTrue)
  , ("false",     TFalse)
  , ("and",       TAnd)
  , ("or",        TOr)
  , ("not",       TNot)
  , ("mod",       TMod)
  , ("put_line",  TPut_Line)
  , ("get_line",  TGet_Line)
  ]

startsWith :: String -> String -> Bool
startsWith pref s = pref == take (length pref) s
