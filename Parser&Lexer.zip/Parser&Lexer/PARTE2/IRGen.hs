module IRGeneration
  ( generateIR
  ) where

import AST
import IR
import qualified Data.Map as Map
import Control.Monad.State

-- Map each variable name to the register where it lives
type VarEnv = Map.Map String String

data CGState = CGState
  { nextTemp  :: Int        -- for t0, t1, ...
  , nextLabel :: Int        -- for L0, L1, ...
  , varEnv    :: VarEnv
  }

type CG = State CGState

-- Public entry point
generateIR :: Exp -> [Instr]
generateIR ast =
  let initState = CGState { nextTemp = 0, nextLabel = 0, varEnv = Map.empty }
  in evalState (genProgram ast) initState

-- ========= Helpers for fresh names =========

freshTemp :: CG String
freshTemp = do
  st <- get
  let n = nextTemp st
  put st { nextTemp = n + 1 }
  return ("t" ++ show n)      -- MIPS: $t0, $t1, ...

freshLabel :: String -> CG String
freshLabel prefix = do
  st <- get
  let n = nextLabel st
  put st { nextLabel = n + 1 }
  return (prefix ++ show n)

lookupVarReg :: String -> CG String
lookupVarReg name = do
  st <- get
  case Map.lookup name (varEnv st) of
    Just r  -> return r
    Nothing -> do
      let env    = varEnv st
          newReg = "s" ++ show (Map.size env)   -- $s0, $s1, ...
          env'   = Map.insert name newReg env
      put st { varEnv = env' }
      return newReg

-- ========= Top-level and statements =========

genProgram :: Exp -> CG [Instr]
genProgram (Program (Block stmts)) = genStmts stmts
genProgram e = error $ "Expected Program(Block ...), got: " ++ show e

genStmts :: [Exp] -> CG [Instr]
genStmts [] = return []
genStmts (s:ss) = do
  c1 <- genStmt s
  c2 <- genStmts ss
  return (c1 ++ c2)

genStmt :: Exp -> CG [Instr]
-- x := expr;
genStmt (Assign (Var name) expr) = do
  (rExpr, codeExpr) <- genExpr expr
  rVar <- lookupVarReg name
  let instr = MOVE rVar rExpr
  return (codeExpr ++ [instr])

-- Put_Line(expr);
genStmt (PutLine expr) = do
  (rExpr, codeExpr) <- genExpr expr
  return (codeExpr ++ [PRINTLN rExpr])

-- Get_Line(x);
genStmt (GetLine name) = do
  rVar <- lookupVarReg name
  return [READ rVar]

-- if cond then stmts end if;
genStmt (If cond (Block thn)) = do
  lThen <- freshLabel "then"
  lEnd  <- freshLabel "endif"

  condCode <- genCond cond lThen lEnd
  thnCode  <- genStmts thn

  return (condCode
          ++ [LABEL lThen]
          ++ thnCode
          ++ [JUMP lEnd, LABEL lEnd])

-- if cond then stmts else stmts end if;
genStmt (IfElse cond (Block thn) (Block els)) = do
  lThen <- freshLabel "then"
  lElse <- freshLabel "else"
  lEnd  <- freshLabel "endif"

  condCode <- genCond cond lThen lElse
  thnCode  <- genStmts thn
  elsCode  <- genStmts els

  return (condCode
          ++ [LABEL lThen]
          ++ thnCode
          ++ [JUMP lEnd, LABEL lElse]
          ++ elsCode
          ++ [JUMP lEnd, LABEL lEnd])

-- while cond loop body end loop;
genStmt (While cond (Block body)) = do
  lCond <- freshLabel "while_cond"
  lBody <- freshLabel "while_body"
  lEnd  <- freshLabel "while_end"

  bodyCode <- genStmts body
  condCode <- genCond cond lBody lEnd

  return ([LABEL lCond]
          ++ condCode
          ++ [LABEL lBody]
          ++ bodyCode
          ++ [JUMP lCond, LABEL lEnd])

-- Nested blocks
genStmt (Block ss) = genStmts ss

genStmt e =
  error $ "Unsupported statement in IR generation: " ++ show e

-- ========= Arithmetic & simple expressions =========
-- Note: here we also allow Bool literals (encode as 0/1) so that
-- you can do things like x := True; or Put_Line(True);

genExpr :: Exp -> CG (String, [Instr])
genExpr (Num n) = do
  t <- freshTemp
  return (t, [MOVEI t n])

genExpr (Bool True) = do
  t <- freshTemp
  return (t, [MOVEI t 1])

genExpr (Bool False) = do
  t <- freshTemp
  return (t, [MOVEI t 0])

genExpr (Var name) = do
  r <- lookupVarReg name
  return (r, [])

genExpr (Add e1 e2)  = genBinArith ADD  e1 e2
genExpr (Sub e1 e2)  = genBinArith SUB  e1 e2
genExpr (Mult e1 e2) = genBinArith MULT e1 e2
genExpr (Div e1 e2)  = genBinArith DIV  e1 e2
genExpr (Mod e1 e2)  = genBinArith MOD  e1 e2

-- Booleans and relations that are *only* for conditions should not reach here
genExpr e =
  error $ "genExpr called on non-arithmetic/boolean expression: " ++ show e

genBinArith :: (String -> String -> String -> Instr) -> Exp -> Exp -> CG (String, [Instr])
genBinArith opCtor e1 e2 = do
  (r1, c1) <- genExpr e1
  (r2, c2) <- genExpr e2
  t <- freshTemp
  let instr = opCtor t r1 r2
  return (t, c1 ++ c2 ++ [instr])

-- ========= Boolean / conditional code =========
-- genCond e lTrue lFalse: if e is true -> jump to lTrue, else to lFalse

genCond :: Exp -> String -> String -> CG [Instr]
-- OR short-circuit
genCond (Or e1 e2) lTrue lFalse = do
  lMid <- freshLabel "or_mid"
  c1 <- genCond e1 lTrue lMid
  c2 <- genCond e2 lTrue lFalse
  return (c1 ++ [LABEL lMid] ++ c2)

-- AND short-circuit
genCond (And e1 e2) lTrue lFalse = do
  lMid <- freshLabel "and_mid"
  c1 <- genCond e1 lMid lFalse
  c2 <- genCond e2 lTrue lFalse
  return (c1 ++ [LABEL lMid] ++ c2)

-- NOT
genCond (Not e) lTrue lFalse =
  genCond e lFalse lTrue

-- Comparison operators
genCond (Equal     e1 e2) lTrue lFalse = genRelCond Eq    e1 e2 lTrue lFalse
genCond (Diff      e1 e2) lTrue lFalse = genRelCond Neq   e1 e2 lTrue lFalse
genCond (Less      e1 e2) lTrue lFalse = genRelCond Lt    e1 e2 lTrue lFalse
genCond (LessEq    e1 e2) lTrue lFalse = genRelCond LtEq  e1 e2 lTrue lFalse
genCond (Greater   e1 e2) lTrue lFalse = genRelCond Gt    e1 e2 lTrue lFalse
genCond (GreaterEq e1 e2) lTrue lFalse = genRelCond GtEq  e1 e2 lTrue lFalse

-- Boolean literals
genCond (Bool True)  lTrue _     = return [JUMP lTrue]
genCond (Bool False) _    lFalse = return [JUMP lFalse]

-- Variable used directly as condition: nonzero is true
genCond (Var name) lTrue lFalse = do
  (r, code) <- genExpr (Var name)
  let instr = COND r Neq "zero" lTrue lFalse  -- compare with $zero
  return (code ++ [instr])

-- Anything else is invalid in a condition (according to the grammar)
genCond e _ _ =
  error $ "Invalid expression in condition: " ++ show e

genRelCond :: BinOp -> Exp -> Exp -> String -> String -> CG [Instr]
genRelCond bop e1 e2 lTrue lFalse = do
  (r1, c1) <- genExpr e1
  (r2, c2) <- genExpr e2
  let instr = COND r1 bop r2 lTrue lFalse
  return (c1 ++ c2 ++ [instr])
