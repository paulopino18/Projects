module MIPSCodeGeneration (generateMIPS) where

import IR
import Data.List (intercalate)

-- | Main entry point: converts a list of IR instructions to a MIPS program string.
generateMIPS :: [Instr] -> String
generateMIPS instrs = unlines $
  [ ".data"
  , "  newline: .asciiz \"\\n\""
  , ""
  , ".text"
  , ".globl main"
  , "main:"
  ] ++ map genInstr instrs ++
  [ ""
  , "  # Exit program properly"
  , "  li $v0, 10"
  , "  syscall"
  ]

-- | Maps a single IR instruction to MIPS assembly lines.
genInstr :: Instr -> String
genInstr instr = case instr of
  -- Label
  LABEL l -> l ++ ":"

  -- Unconditional Jump
  JUMP l -> "  j " ++ l

  -- Register Move: dest = src
  MOVE dest src ->
    "  move " ++ fmtReg dest ++ ", " ++ fmtReg src

  -- Immediate Load: dest = val
  MOVEI dest val ->
    "  li " ++ fmtReg dest ++ ", " ++ show val

  -- String Move (Not strictly used in your IRGen, but defined in IR)
  MOVES dest str ->
    "  # MOVES not fully implemented without .data management for: " ++ str

  -- Arithmetic
  ADD dest s1 s2 ->
    "  add " ++ fmtReg dest ++ ", " ++ fmtReg s1 ++ ", " ++ fmtReg s2

  SUB dest s1 s2 ->
    "  sub " ++ fmtReg dest ++ ", " ++ fmtReg s1 ++ ", " ++ fmtReg s2

  MULT dest s1 s2 ->
    "  mul " ++ fmtReg dest ++ ", " ++ fmtReg s1 ++ ", " ++ fmtReg s2

  DIV dest s1 s2 ->
    -- Integer division: quotient in Lo
    "  div " ++ fmtReg s1 ++ ", " ++ fmtReg s2 ++ "\n" ++
    "  mflo " ++ fmtReg dest

  MOD dest s1 s2 ->
    -- Modulo: remainder in Hi
    "  div " ++ fmtReg s1 ++ ", " ++ fmtReg s2 ++ "\n" ++
    "  mfhi " ++ fmtReg dest

  -- Conditional Branching: if (r1 op r2) goto lTrue else goto lFalse
  COND r1 op r2 lTrue lFalse ->
    let branchOp = case op of
          Eq   -> "beq"
          Neq  -> "bne"
          Lt   -> "blt"
          LtEq -> "ble"
          Gt   -> "bgt"
          GtEq -> "bge"
    in unlines
       [ "  " ++ branchOp ++ " " ++ fmtReg r1 ++ ", " ++ fmtReg r2 ++ ", " ++ lTrue
       , "  j " ++ lFalse
       ]

  -- Boolean Operations
  AND dest s1 s2 ->
    "  and " ++ fmtReg dest ++ ", " ++ fmtReg s1 ++ ", " ++ fmtReg s2

  OR dest s1 s2 ->
    "  or " ++ fmtReg dest ++ ", " ++ fmtReg s1 ++ ", " ++ fmtReg s2

  NOT dest src ->
    -- Logic NOT for 0/1 booleans: XOR with 1 flips the bit
    "  xori " ++ fmtReg dest ++ ", " ++ fmtReg src ++ ", 1"

  -- I/O Operations (using MARS Syscalls)
  
  --Print Integer (Syscall 1)
  PRINT r ->
    unlines
      [ "  li $v0, 1"
      , "  move $a0, " ++ fmtReg r
      , "  syscall"
      ]

  -- Print Line: Integer + Newline
  PRINTLN r ->
    unlines
      [ "  # Print Integer"
      , "  li $v0, 1"
      , "  move $a0, " ++ fmtReg r
      , "  syscall"
      , "  # Print Newline"
      , "  li $v0, 11"      -- Syscall 11: print_char
      , "  li $a0, 10"      -- ASCII 10 is newline
      , "  syscall"
      ]

  -- Read Integer (Syscall 5)
  READ r ->
    unlines
      [ "  li $v0, 5"       -- Syscall 5: read_int
      , "  syscall"
      , "  move " ++ fmtReg r ++ ", $v0"
      ]

-- | Helper to format register names (adds '$' prefix)
fmtReg :: String -> String
fmtReg r = "$" ++ r