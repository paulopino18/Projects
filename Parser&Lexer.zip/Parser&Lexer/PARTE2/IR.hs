module IR where
-- facilita a traducao para assembley(three adress code)

-- Binary relational operators for conditions
data BinOp
  = Eq    -- ==
  | Neq   -- /=
  | Lt    -- <
  | LtEq  -- <=
  | Gt    -- >
  | GtEq  -- >=
  deriving (Show, Eq)

-- Three-address-style instructions
data Instr
  = MOVE  String String              -- MOVE dest src        (registers)
  | MOVEI String Int                 -- MOVEI dest immediate
  | MOVES String String              -- MOVES dest "string"
  | ADD   String String String       -- dest = src1 + src2
  | SUB   String String String       -- dest = src1 - src2
  | MULT  String String String       -- dest = src1 * src2
  | DIV   String String String       -- dest = src1 / src2
  | MOD   String String String       -- dest = src1 mod src2
  | LABEL String                     -- label:
  | JUMP  String                     -- unconditional jump
  | COND  String BinOp String String String
    -- COND r1 op r2 labelTrue labelFalse
  | NOT   String String              -- dest = NOT src
  | AND   String String String       -- dest = src1 AND src2
  | OR    String String String       -- dest = src1 OR src2
  | PRINT   String                   -- print without newline
  | PRINTLN String                   -- print with newline
  | READ   String                    -- read integer into dest
  deriving (Show, Eq)
