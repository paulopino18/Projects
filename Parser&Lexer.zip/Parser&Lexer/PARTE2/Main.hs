module Main where

import Lexer (tokenize)
import Parser (parser)
import AST
import Semantics (semanticAnalysis)
import IRGeneration (generateIR)
import MIPSCodeGeneration (generateMIPS)
import System.Environment (getArgs)
import System.IO (hPutStrLn, stderr)

main :: IO ()
main = do
  src <- getContents
  
  -- 1) Lexing
  let toks = tokenize src
  
  -- 2) Parsing
  let ast = parser toks
  
  -- 3) Semantic Analysis
  case semanticAnalysis ast of
    Left err -> hPutStrLn stderr ("Error: " ++ err) -- Print errors to stderr
    Right _ -> do
      -- 4) IR Generation
      let ir = generateIR ast
      
      -- 5) MIPS Generation
      let mips = generateMIPS ir
      
      -- ONLY print the MIPS code to stdout
      putStrLn mips