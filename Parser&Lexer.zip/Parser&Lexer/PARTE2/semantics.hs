module Semantics
  ( Type(..)
  , SymbolTable
  , semanticAnalysis
  ) where

import qualified Data.Map as Map
import AST

-- Simple type system for this subset
data Type = TyInt | TyBool
  deriving (Show, Eq)

-- Symbol table: variable name -> type
type SymbolTable = Map.Map String Type

-- Entry point: run semantic analysis on the whole program
semanticAnalysis :: Exp -> Either String SymbolTable
semanticAnalysis (Program (Block stmts)) =
  analyzeStmts Map.empty stmts
semanticAnalysis _ =
  Left "Program must be of the form: 'procedure Main is begin ... end Main;'."

-- ===== Statements =====

analyzeStmts :: SymbolTable -> [Exp] -> Either String SymbolTable
analyzeStmts env [] = Right env
analyzeStmts env (s:ss) = do
  env' <- analyzeStmt env s
  analyzeStmts env' ss

analyzeStmt :: SymbolTable -> Exp -> Either String SymbolTable
-- x := expr;
analyzeStmt env (Assign (Var x) e) = do
  t <- inferType env e
  case Map.lookup x env of
    Nothing  ->  -- first assignment defines the variable
      Right (Map.insert x t env)
    Just tx ->
      if tx == t
        then Right env
        else Left $
          "Type mismatch in assignment to '" ++ x ++
          "': expected " ++ show tx ++ ", got " ++ show t

-- Put_Line(expr);  (we allow int or bool)
analyzeStmt env (PutLine e) =
  inferType env e >> Right env

-- Get_Line(x);  (treat input as integer)
analyzeStmt env (GetLine x) =
  case Map.lookup x env of
    Nothing  -> Right (Map.insert x TyInt env)
    Just tx ->
      if tx == TyInt
        then Right env
        else Left $
          "Get_Line reads an integer, but '" ++ x ++
          "' already has type " ++ show tx

-- if cond then Block thn end if;
analyzeStmt env (If cond (Block thn)) = do
  tcond <- inferType env cond
  if tcond /= TyBool
    then Left "IF condition must be boolean."
    else do
      _ <- analyzeStmts env thn
      Right env

-- if cond then Block thn else Block els end if;
analyzeStmt env (IfElse cond (Block thn) (Block els)) = do
  tcond <- inferType env cond
  if tcond /= TyBool
    then Left "IF-ELSE condition must be boolean."
    else do
      _ <- analyzeStmts env thn
      _ <- analyzeStmts env els
      Right env

-- while cond loop Block body end loop;
analyzeStmt env (While cond (Block body)) = do
  tcond <- inferType env cond
  if tcond /= TyBool
    then Left "WHILE condition must be boolean."
    else do
      _ <- analyzeStmts env body
      Right env

-- Nested blocks (if any)
analyzeStmt env (Block ss) = analyzeStmts env ss

analyzeStmt _ e =
  Left $ "Unsupported statement in semantic analysis: " ++ show e

-- ===== Expressions =====

inferType :: SymbolTable -> Exp -> Either String Type
inferType _   (Num _)    = Right TyInt
inferType _   (Bool _)   = Right TyBool
inferType env (Var x) =
  case Map.lookup x env of
    Nothing  -> Left $ "Variable '" ++ x ++ "' used before assignment."
    Just t   -> Right t

-- arithmetic
inferType env (Add e1 e2)  = arith env e1 e2
inferType env (Sub e1 e2)  = arith env e1 e2
inferType env (Mult e1 e2) = arith env e1 e2
inferType env (Div e1 e2)  = arith env e1 e2
inferType env (Mod e1 e2)  = arith env e1 e2

-- boolean connectives
inferType env (And e1 e2)  = bool2 env e1 e2
inferType env (Or  e1 e2)  = bool2 env e1 e2
inferType env (Not e) = do
  t <- inferType env e
  if t == TyBool then Right TyBool
                 else Left "NOT expects a boolean expression."

-- comparisons: Int ? Int -> Bool
inferType env (Equal e1 e2)      = cmp env e1 e2
inferType env (Diff e1 e2)       = cmp env e1 e2
inferType env (Less e1 e2)       = cmp env e1 e2
inferType env (LessEq e1 e2)     = cmp env e1 e2
inferType env (Greater e1 e2)    = cmp env e1 e2
inferType env (GreaterEq e1 e2)  = cmp env e1 e2

inferType _ e =
  Left $ "inferType called on non-expression: " ++ show e

-- helpers
arith :: SymbolTable -> Exp -> Exp -> Either String Type
arith env e1 e2 = do
  t1 <- inferType env e1
  t2 <- inferType env e2
  if t1 == TyInt && t2 == TyInt
    then Right TyInt
    else Left "Arithmetic operators require integer operands."

bool2 :: SymbolTable -> Exp -> Exp -> Either String Type
bool2 env e1 e2 = do
  t1 <- inferType env e1
  t2 <- inferType env e2
  if t1 == TyBool && t2 == TyBool
    then Right TyBool
    else Left "Boolean operators require boolean operands."

cmp :: SymbolTable -> Exp -> Exp -> Either String Type
cmp env e1 e2 = do
  t1 <- inferType env e1
  t2 <- inferType env e2
  if t1 == TyInt && t2 == TyInt
    then Right TyBool
    else Left "Relational operators require integer operands."
