module Main where

import Lexer (alexScanTokens)
import Parser (parser)
import AST

main :: IO ()
main = do
  src <- getContents
  let toks = alexScanTokens src
  putStrLn "---- TOKENS ----"
  print toks
  let ast = parser toks
  putStrLn "---- AST ----"
  print ast
